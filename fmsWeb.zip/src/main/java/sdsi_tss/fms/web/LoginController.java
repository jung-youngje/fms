package sdsi_tss.fms.web;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import sdsi_tss.fms.cmmn.CommonProperties.MSGINFO;
import sdsi_tss.fms.cmmn.CommonProperties.SESSION_ID;
import sdsi_tss.fms.cmmn.CommonProperties.VALUECONST;
import sdsi_tss.fms.cmmn.FilterUtil;
import sdsi_tss.fms.cmmn.UserLogger;
import sdsi_tss.fms.service.CustUserVO;
import sdsi_tss.fms.service.LoginService;
import sdsi_tss.fms.service.SwInfoVO;

@Controller
public class LoginController {

	@Resource(name = "loginService")
	private LoginService loginService;

	/**
	 * �α��� ȭ���� ���̵�+�޴���ȭ��ȣ �Ǵ� �̸���: �α��� �ϱ�
	 * 
	 * @param login_id : ȭ���� ���̵�	
	 * @param login_hp_email : �޴���ȭ��ȣ �Ǵ� �̸���
	 * @param request
	 * @param response
	 * @return ó�����(JSON)
	 */
	@RequestMapping("/loginComfirm.ajax")
	public @ResponseBody Map<String, String> loginComfirm(@RequestParam("login_id") String login_id,
			@RequestParam("login_hp_email") String login_hp_email,
			HttpServletRequest request, HttpServletResponse response) {
		
		response.setHeader("P3P","CP='CAO PSA CONi OTR OUR DEM ONL'");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 0);
		
		Map<String, String> map = new HashMap<String, String>();
		HttpSession session = request.getSession();	
		Logger usrLogger = null;
		
		//-----
		login_id = FilterUtil.getXSSFilter(login_id);
		login_id = FilterUtil.getSQLInjectionFilter(login_id);
		
		login_hp_email = FilterUtil.getXSSFilter(login_hp_email);
		login_hp_email = FilterUtil.getSQLInjectionFilter(login_hp_email);
		//-----
		
		try {
			// ��ü���̵� ���� ���
			CustUserVO userData = loginService.login(login_id);
							
			// ���̵� �������� ���� ���
			if(userData == null) {								
				//USERLOG: Unknown user
				usrLogger = UserLogger.getLogger();

				map.put("RESULT_KEY","NG");
				map.put("Message",MSGINFO.ID_STATUS);	//���� ID
				
				usrLogger.error("Login|NG|" + MSGINFO.ID_STATUS + "(" + login_id +")");
				return map;

			}else {
				//USERLOG: Registered user
				usrLogger = UserLogger.getLogger(login_id);
								
				if(userData.getCust_id().equals(login_id) && 
					(!userData.getUser_cell().equals(login_hp_email) && !userData.getUser_email().equals(login_hp_email)) ){
					map.put("RESULT_KEY","NG");
					map.put("Message",MSGINFO.HP_EMAIL_STATUS);	// �޴���ȭ��ȣ �Ǵ� �̸��� ����ġ
		
					usrLogger.error("Login|NG|" + MSGINFO.HP_EMAIL_STATUS);
					return map;	
				}				
				
				if(userData.getKubun().equals(VALUECONST.USER_KUBUN_CUST)){
					if(!userData.getCust_status().equals(VALUECONST.CUST_STATUS)){ //0004�� �ƴϸ�
						map.put("RESULT_KEY","NG");
						map.put("Message",MSGINFO.STATUS_MSG);	// �޴���ȭ��ȣ �Ǵ� �̸��� ����ġ

						usrLogger.error("Login|NG|" + MSGINFO.STATUS_MSG);
						return map;							
					}
					
				}else{
					//���α׷����̵� ���� ���
					SwInfoVO van = loginService.van(login_id);
					
					//VAN ���� NG
					if(!van.toString().contains(VALUECONST.SERVICE_FLAG_Y) 
							&& !van.toString().contains(VALUECONST.SERVICE_FLAG_D)){
						map.put("RESULT_KEY","NG");
						map.put("Message",MSGINFO.NO_MSG);	// �޴���ȭ��ȣ �Ǵ� �̸��� ����ġ
			
						usrLogger.info("Login|NG|" + MSGINFO.NO_MSG);
						return map;							
					}
				}
				
				// CUST/VAN ���� OK
				map.put("RESULT_KEY","OK");
				map.put("Message",login_id);	// �α��� ���̵� ����
			
				session.setAttribute(SESSION_ID.USER_ID, login_id);
				session.setAttribute(SESSION_ID.USER_CELL, userData.getUser_cell());
				session.setAttribute(SESSION_ID.USER_NAME, userData.getCust_nm());
				session.setAttribute(SESSION_ID.USERID_KUBUN, userData.getKubun());
				session.setAttribute(SESSION_ID.LOGIN_OK_FLAG, "1");

				usrLogger.info("Login|OK");
				return map;
			}
			
		} catch (Exception e) {
			try { usrLogger.error("loginComfirm|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
			
			map.put("RESULT_KEY","ERR");
			map.put("Message", e.getMessage());	// �α��� ���̵� ����
		}
		
		return map;	
	}
	
	@RequestMapping("/login_old.do")
	public ModelAndView login_old(String login_id, String login_hp_email, HttpServletRequest request) throws Exception{

		HttpSession session = request.getSession();
		ModelAndView mav = new ModelAndView();
				
		//��ü���̵� ���� ���
		CustUserVO login = loginService.login(login_id);
		//���α׷����̵� ���� ���
		SwInfoVO van = loginService.van(login_id);
		
		if(login==null){
			if(login_id==""){ //���̵� �����϶�
				mav.addObject("status", MSGINFO.ID_CHECK); //���� ID
			}else if(login_id!=null && login_id!="" && login_hp_email==""){
				mav.addObject("status", MSGINFO.HP_EMAIL_CHECK); //���̵� �ԷµǾ� �ְ� �ڵ����� �����϶�
			}
			falseMethod(session, mav);
			
		}else{
			if(login.getCust_id().equals(login_id) && (!login.getUser_cell().equals(login_hp_email) 
					&& !login.getUser_email().equals(login_hp_email) || login_hp_email=="")){
				if(login_hp_email==""){
					mav.addObject("status", MSGINFO.HP_EMAIL_CHECK);//���̵� �Է°� �ְ� ��й�ȣ �����϶�
				}else{
					mav.addObject("status", MSGINFO.HP_EMAIL_STATUS);
				}
				falseMethod(session, mav);
			}else{
				if(login.getKubun().equals(VALUECONST.USER_KUBUN_CUST)){
					if(!login.getCust_status().equals(VALUECONST.CUST_STATUS)){ //0004�� �ƴϸ�
						mav.addObject("status",MSGINFO.STATUS_MSG); //���񽺻���Ȯ��
						falseMethod(session, mav);
					}else{ //CUST ���� OK
						okMethod(session, mav, login_id, login);
					}
				}else{
					if(!van.toString().contains(VALUECONST.SERVICE_FLAG_Y) 
							&& !van.toString().contains(VALUECONST.SERVICE_FLAG_D)){
						mav.addObject("status",MSGINFO.NO_MSG); //���� ���Ұ�
						falseMethod(session, mav);
					}else{ //VAN ���� OK
						okMethod(session, mav, login_id, login);
						
					}
				}
			}				
		}
		
		mav.addObject("login", login);
		return mav;	
	}
	
	public void okMethod(HttpSession session, ModelAndView mav,
			String login_id, CustUserVO login) throws Exception {
		
		mav.setViewName("../../index");
		mav.addObject("center", "/WEB-INF/view/jsp/hp_auth.jsp");
		/*
		session.setAttribute(SESSION_ID.USER_ID, login_id);
		session.setAttribute(SESSION_ID.USER_CELL, login.getUser_cell());
		session.setAttribute(SESSION_ID.USER_NAME, login.getCust_nm());
		session.setAttribute(SESSION_ID.USERID_KUBUN, login.getKubun());
		*/
	}
	
	public void falseMethod(HttpSession session, ModelAndView mav)throws Exception{
		mav.setViewName("../../index");
		mav.addObject("center", "/WEB-INF/view/jsp/Login.jsp");
	}

}