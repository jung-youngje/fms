package sdsi_tss.fms.web;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import sdsi_tss.fms.cmmn.UtilData;
import sdsi_tss.fms.cmmn.CommonProperties.SESSION_ID;
import sdsi_tss.fms.service.NoticeService;
import sdsi_tss.fms.service.NoticeVO;

@Controller
public class MainController {

	@Resource(name = "noticeService")
	private NoticeService noticeService;

	/**
	 * ���� ȭ���� ǥ�� (�������� ǥ��)
	 * 
	 * @param session
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/main.do")
	public ModelAndView mainView(HttpSession session, HttpServletRequest request) throws Exception{
		Logger usrLogger = UtilData.getLoggerInstance(session);		
		usrLogger.info("���� ȭ�� Loading : /main.do");	
		List<NoticeVO> list = null;
		
		try {
			list = noticeService.mainList();
	
			// ������ ���ڼ��� 18���� ���� ��� 18���ڸ� �����ְ� ... �߰�
			for (int i = 0; i < list.size(); i++) {
				NoticeVO Nbean = list.get(i);
	
				if (Nbean.getSubject().length() > 16) {
					String subject = Nbean.getSubject().substring(0, 16).concat("...");
					Nbean.setSubject(subject);
				}
			}		
			
		}catch (Exception e) {
			try { usrLogger.error("mainView|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		String url = "/index";
		ModelAndView mav = new ModelAndView(url);
		mav.addObject("top", UtilData.makeTopPage(session));
		mav.addObject("center", "main.jsp");
		mav.addObject("list", list);
		
		return mav;
	}
	
	/**
	 * �α��� ȭ�� ǥ��
	 * 
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/login.do")
	public ModelAndView loginView(HttpServletRequest request, HttpSession session ) throws Exception{
		Logger usrLogger = UtilData.getLoggerInstance(session);		
		usrLogger.info("�α��� ȭ�� Loading");	
		
		String topPage = UtilData.makeTopPage(session);
		String moveUrl ="/index";

		ModelAndView mav = new ModelAndView();
		mav.setViewName(moveUrl);
		
		mav.addObject("top", topPage);
		mav.addObject("center", "Login.jsp");
		
		return mav;
	}
	
	/**
	 * �������̵� ȭ�� ǥ��
	 * 
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/guide.do")
	public ModelAndView guideView(HttpServletRequest request, HttpSession session ) throws Exception{
		Logger usrLogger = UtilData.getLoggerInstance(session);		
		usrLogger.info("�������̵� ȭ�� Loading");	
		
		String topPage = UtilData.makeTopPage(session);
		String moveUrl ="/index";

		ModelAndView mav = new ModelAndView();
		mav.setViewName(moveUrl);
		
		mav.addObject("top", topPage);
		mav.addObject("center", "guide.jsp");
		
		return mav;
	}
	
	/**
	 * �����ڵ�˻� ȭ�� ǥ��
	 * 
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/errorcodeView.do")
	public ModelAndView errorcodeView(HttpServletRequest request, HttpSession session ) throws Exception{
		Logger usrLogger = UtilData.getLoggerInstance(session);		
		usrLogger.info("�����ڵ�˻� ȭ�� Loading");	
		
		String topPage = UtilData.makeTopPage(session);
		String moveUrl ="/index";

		ModelAndView mav = new ModelAndView();
		mav.setViewName(moveUrl);
		
		mav.addObject("top", topPage);
		mav.addObject("center", "errorcode.jsp");
		
		return mav;
	}
	
	/**
	 * FAQ ȭ�� ǥ��
	 * 
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/faq.do")
	public ModelAndView faqView(HttpServletRequest request, HttpSession session ) throws Exception{
		Logger usrLogger = UtilData.getLoggerInstance(session);		
		usrLogger.info("FAQ ȭ�� Loading");	
		
		String topPage = UtilData.makeTopPage(session);
		String moveUrl ="/index";

		ModelAndView mav = new ModelAndView();
		mav.setViewName(moveUrl);
		
		mav.addObject("top", topPage);
		mav.addObject("center", "faq.jsp");
		
		return mav;
	}
	
	/**
	 * �α��� ���� ȭ��
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("loginOk.do")
	public ModelAndView loginOk(HttpServletRequest request, HttpServletResponse response) throws Exception{
		HttpSession session = request.getSession();		
		Logger usrLogger = UtilData.getLoggerInstance(session);		
		usrLogger.info("�α���OK, �޴��� ����ȭ�� ǥ��");
		
		if (session.getAttribute(SESSION_ID.USER_ID) == null) {
	        response.sendRedirect(request.getContextPath()+"/");
            return null;
        }
		
		ModelAndView mav = new ModelAndView();
		String moveUrl ="/index";
				
		mav.setViewName(moveUrl);
		mav.addObject("top", UtilData.makeTopPage(session));
		mav.addObject("center", "hp_auth.jsp");
		
		return mav;
	}

	/**
	 * �α׾ƿ� ȭ��
	 * 
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/logout.do")
	public ModelAndView logout(HttpServletRequest request,HttpSession session) throws Exception {
		
		Logger usrLogger = UtilData.getLoggerInstance(session);

		//�α��� ���� ����
		if(session != null) {
			session.setAttribute(SESSION_ID.USER_ID, null);
			session.setAttribute(SESSION_ID.USER_CELL, null);
			session.setAttribute(SESSION_ID.USER_NAME, null);
			session.setAttribute(SESSION_ID.USERID_KUBUN, null);
			session.setAttribute(SESSION_ID.HANDPHONE_NO, null);
			session.setAttribute(SESSION_ID.HP_AUTH_OK, null);
		}
		
		usrLogger.info("/logout.do | �α׾ƿ�" );
		ModelAndView mav = new ModelAndView();
		mav = mainView(session,request);
		
		return mav;
	}
	
	/**
	 * ���� ȭ��
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/index.do")
	public ModelAndView mainContainer(HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();		
		Logger usrLogger = UtilData.getLoggerInstance(session);
		usrLogger.info("���� ȭ�� Loading : /index.do");

		session.invalidate();		
		String url = "/index";
		
		ModelAndView mav = new ModelAndView(url);
		mav.addObject("top", UtilData.makeTopPage(session));
		mav.addObject("center", null);
		
		return mav;
	}
}