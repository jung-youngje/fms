package sdsi_tss.fms.web;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import sdsi_tss.fms.cmmn.CommonProperties.*;
import sdsi_tss.fms.cmmn.FilterUtil;
import sdsi_tss.fms.cmmn.UtilData;
import sdsi_tss.fms.service.MobileConfirmService;
import sdsi_tss.fms.service.MobileConfirmVO;

@Controller
public class MobileLoginController {
	
	@Resource(name = "mobileConfirmService")
	private MobileConfirmService mobileService;

	/**
	 * 휴대전화 인증
	 * 
	 * @param hp_no
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 */
	@RequestMapping("/mobileConfirm.ajax")
	public @ResponseBody Map<String, String> mobileConfirm(@RequestParam("hp_no") String hp_no,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		
		Map<String, String> map = new HashMap<String, String>();
		Logger usrLogger = UtilData.getLoggerInstance(session);
		usrLogger.info("휴대전화 인증 하기 Loading");	
		
		hp_no = FilterUtil.getXSSFilter(hp_no);
		hp_no = FilterUtil.getSQLInjectionFilter(hp_no);
		
		try {
			String member_id = (String)session.getAttribute(SESSION_ID.USER_ID);
			String handPhoneNo = session.getAttribute(SESSION_ID.USER_CELL) != null ? session.getAttribute(SESSION_ID.USER_CELL).toString() : "";
						
			if (!handPhoneNo.equals(hp_no) ) {				
				map.put("RESULT_KEY","NG");
				map.put("Message",MSGINFO.AUTH_HPNO_ERROR);
				usrLogger.info(MSGINFO.AUTH_HPNO_ERROR);	
				return map;	
			}
	
			//휴대전화 인증 정보 등록
			boolean actionRst = mobileService.setMobileConfrimInfo(member_id,hp_no);
			if(actionRst == false) {
				map.put("RESULT_KEY","NG");
				map.put("Message",MSGINFO.SMS_SEND_ERROR);			
				usrLogger.info(MSGINFO.SMS_SEND_ERROR);
				return map;	
			}
	
			session.setAttribute(SESSION_ID.HANDPHONE_NO, hp_no);
			map.put("RESULT_KEY","OK");
			map.put("Message","");
			
		}catch (Exception e) {
			map.put("RESULT_KEY","NG");
			map.put("Message","");
			try { usrLogger.error("mobileConfirm|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		return map;
	}
	
	/**
	 * 휴대전화 인증번호 확인 화면 표시(팝업)
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/mobileConfirmPop.do")
	public ModelAndView mobileConfirmPopView() throws Exception {
		ModelAndView mav = new ModelAndView("");	
		mav.setViewName("/hp_auth_pop");
		return mav;
	}
	

	/**
	 * 휴대전화번호 인증화면의 확인버튼 실행
	 * @param sms_auth_no : 인증번호
	 * @param request
	 * @return 처리결과
	 * @throws Exception
	 */
	@RequestMapping("/mobileConfirmCheck.do")
	public ModelAndView mobileConfirmCheck(@RequestParam("sms_auth_no") String sms_auth_no,
			HttpServletRequest request) throws Exception {
		
		ModelAndView mav = new ModelAndView();
		String errorMsg = "";
		int errorResult = 1;		
		int authNoErrorCount = 0;
		
		HttpSession session = request.getSession();	
		String memberId = session.getAttribute(SESSION_ID.USER_ID)!= null ? session.getAttribute(SESSION_ID.USER_ID).toString() : "";
		String handPhoneNo = session.getAttribute(SESSION_ID.HANDPHONE_NO) != null ? session.getAttribute(SESSION_ID.HANDPHONE_NO).toString() : "";
		String authErrCnt = session.getAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT) != null ? session.getAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT).toString() : "0";
		authNoErrorCount = Integer.parseInt(authErrCnt);
		
		sms_auth_no = FilterUtil.getXSSFilter(sms_auth_no);
		sms_auth_no = FilterUtil.getSQLInjectionFilter(sms_auth_no);
		
		Logger usrLogger = UtilData.getLoggerInstance(session);
		usrLogger.info("휴대전화 인증번화 확인");	
		
		try {
			//인증횟수 체크
			if (authNoErrorCount > SMSINFO.CHECK_LIMITED_AUTH_TRY) {			
				session.setAttribute(SESSION_ID.HP_AUTH_OK, null);			
				mav.setViewName("/hp_auth_pop");
				mav.addObject("errorResult", "-1");
				mav.addObject("errormsg", MSGINFO.SMS_TRY_ERROR );
				usrLogger.info(MSGINFO.SMS_TRY_ERROR );	
				return mav;		
			}
			
			MobileConfirmVO searchVo = new MobileConfirmVO();
			searchVo.setAuth_id(memberId);
			searchVo.setAuth_tel(handPhoneNo);
			searchVo.setAuth_token(sms_auth_no);
				
			//휴대전화 인증 정보 등록
			MobileConfirmVO actionRst = mobileService.getSdsiAuthLogInfo(searchVo);
			if(actionRst == null) {
				errorResult = -1;
				errorMsg = MSGINFO.SMS_ERROR;
				usrLogger.info(MSGINFO.SMS_ERROR );	
				
			} else {
				String currDateTime = UtilData.getNowDateTime();
				int rtn = UtilData.getCalculateDateTime(actionRst.getAuth_create_time(), currDateTime);
				if(rtn < 0) {
					//인증실패				
					errorResult = -1;
					errorMsg = MSGINFO.SMS_ERROR;
					usrLogger.info(MSGINFO.SMS_ERROR );	
				} else if (rtn > SMSINFO.CHECK_LIMITED_MINUTE) {
					//제한 시간 인증실패
					errorResult = -1;
					errorMsg = MSGINFO.SMS_TIME_ERROR;
					usrLogger.info(MSGINFO.SMS_TIME_ERROR );	
				} else {
					//
					//인증 성공
					//
					MobileConfirmVO updateVo = new MobileConfirmVO();
					updateVo.setAuth_id(memberId);
					updateVo.setAuth_tel(handPhoneNo);
					updateVo.setAuth_token(sms_auth_no);
					updateVo.setAuth_token_status(VALUECONST.AUTH_TOKEN_STATUS_0004);
										
					//인증정보 업데이트
					int updResult = mobileService.updateSdsiAuthLogInfo(updateVo);
					if(updResult < 1) {
						errorResult = -1;
					}
				}			
			}
			
			//휴대전화 인증화면
			if (errorResult  < 1) {		
				usrLogger.info("휴대전화번호 인증 실패 (" + authNoErrorCount + 1 + "회)");	
				
				mav.setViewName("/hp_auth_pop");	
				session.setAttribute(SESSION_ID.HP_AUTH_OK, null);
				session.setAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT, authNoErrorCount + 1);
				
				//인증횟수 체크
				if ( (authNoErrorCount + 1 ) >= SMSINFO.CHECK_LIMITED_AUTH_TRY) {
					MobileConfirmVO updateVo = new MobileConfirmVO();
					updateVo.setAuth_id(memberId);
					updateVo.setAuth_tel(handPhoneNo);
					updateVo.setAuth_token_status(VALUECONST.AUTH_TOKEN_STATUS_0003);
					//인증정보 업데이트
					int updResult = mobileService.updateSdsiAuthLogInfoStatus(updateVo);
					if (updResult < 1) {
						errorResult = -1;
					}				
				}
				
			}else {
				
				usrLogger.info("휴대전화번호 인증 OK");					
				mav.setViewName("/hp_auth_pop2");
				session.setAttribute(SESSION_ID.HP_AUTH_OK, "AUTH_OK");
				session.setAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT, "0");
				session.setAttribute(SESSION_ID.LOGIN_OK_FLAG, "3");
			}
		}catch (Exception e ) {
			try { usrLogger.error("mobileConfirmCheck|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		mav.addObject("errorResult", errorResult);
		mav.addObject("errormsg", errorMsg);
		return mav;		
	}
	
	
	/**
	 * 휴대전화번호 인증화면의 확인버튼 실행
	 * @param sms_auth_no : 인증번호
	 * @param request
	 * @return 처리결과
	 * @throws Exception
	 */
	@RequestMapping("/mobileConfirmCheck_ajax.ajax")
	public @ResponseBody Map<String, String> mobileConfirmCheck_ajax(
			@RequestParam("sms_auth_no") String sms_auth_no,
			HttpServletRequest request) throws Exception {
		
		ModelAndView mav = new ModelAndView();
		Map<String, String> map = new HashMap<String, String>();
		
		String errorMsg = "";
		String errorResult = "OK";		
		int authNoErrorCount = 0;
		
		HttpSession session = request.getSession();	
		String memberId = session.getAttribute(SESSION_ID.USER_ID)!= null ? session.getAttribute(SESSION_ID.USER_ID).toString() : "";
		String handPhoneNo = session.getAttribute(SESSION_ID.HANDPHONE_NO) != null ? session.getAttribute(SESSION_ID.HANDPHONE_NO).toString() : "";
		String authErrCnt = session.getAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT) != null ? session.getAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT).toString() : "0";
		authNoErrorCount = Integer.parseInt(authErrCnt);
		
		Logger usrLogger = UtilData.getLoggerInstance(session);
		usrLogger.info("휴대전화 인증번화 확인");	
		
		//--------------
		sms_auth_no = FilterUtil.getXSSFilter(sms_auth_no);
		sms_auth_no = FilterUtil.getSQLInjectionFilter(sms_auth_no);
		//--------------
		
		try {
			//인증횟수 체크
			if (authNoErrorCount >= SMSINFO.CHECK_LIMITED_AUTH_TRY) {			
				session.setAttribute(SESSION_ID.HP_AUTH_OK, null);			
				mav.setViewName("/hp_auth_pop");
				map.put("RESULT_KEY","NG");
				map.put("Message",MSGINFO.SMS_TRY_ERROR);					
				usrLogger.info(MSGINFO.SMS_TRY_ERROR );	
				return map;		
			}
			
			MobileConfirmVO searchVo = new MobileConfirmVO();
			searchVo.setAuth_id(memberId);
			searchVo.setAuth_tel(handPhoneNo);
			searchVo.setAuth_token(sms_auth_no);
				
			//휴대전화 인증 정보 등록
			MobileConfirmVO actionRst = mobileService.getSdsiAuthLogInfo(searchVo);
			if(actionRst == null) {
				errorResult = "NG";
				errorMsg = MSGINFO.SMS_ERROR;
				usrLogger.info(MSGINFO.SMS_ERROR );	
				
			} else {
				String currDateTime = UtilData.getNowDateTime();
				int rtn = UtilData.getCalculateDateTime(actionRst.getAuth_create_time(), currDateTime);
				if (rtn < 0) {
					//인증실패				
					errorResult = "NG";
					errorMsg = MSGINFO.SMS_ERROR;
					usrLogger.info(MSGINFO.SMS_ERROR );	
				} else if(rtn > SMSINFO.CHECK_LIMITED_MINUTE) {
					//제한 시간 인증실패
					errorResult = "NG";
					errorMsg = MSGINFO.SMS_TIME_ERROR;
					usrLogger.info(MSGINFO.SMS_TIME_ERROR );	
				}else {
					//
					//인증 성공
					//
					MobileConfirmVO updateVo = new MobileConfirmVO();
					updateVo.setAuth_id(memberId);
					updateVo.setAuth_tel(handPhoneNo);
					updateVo.setAuth_token(sms_auth_no);
					updateVo.setAuth_token_status(VALUECONST.AUTH_TOKEN_STATUS_0004);
										
					//인증정보 업데이트
					int updResult = mobileService.updateSdsiAuthLogInfo(updateVo);
					if (updResult < 1) {
						errorResult = "NG";
						errorMsg = MSGINFO.SMS_ERROR;
					}
				}			
			}
			
			//휴대전화 인증화면
			if (errorResult.equals("NG")) {		
				
				authNoErrorCount = authNoErrorCount + 1;
				usrLogger.info("휴대전화번호 인증 실패 (" + authNoErrorCount  + "회)");	
				
				mav.setViewName("/hp_auth_pop");	
				session.setAttribute(SESSION_ID.HP_AUTH_OK, null);
				session.setAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT, authNoErrorCount );
				
				//인증횟수 체크
				if ( (authNoErrorCount + 1 ) >= SMSINFO.CHECK_LIMITED_AUTH_TRY) {
					MobileConfirmVO updateVo = new MobileConfirmVO();
					updateVo.setAuth_id(memberId);
					updateVo.setAuth_tel(handPhoneNo);
					updateVo.setAuth_token_status(VALUECONST.AUTH_TOKEN_STATUS_0003);
					//인증정보 업데이트
					int updResult = mobileService.updateSdsiAuthLogInfoStatus(updateVo);
					if (updResult < 1) {
						errorResult = "NG";
						errorMsg = MSGINFO.SMS_ERROR;
					}				
				}
				
			}else {
				
				usrLogger.info("휴대전화번호 인증 OK");					
				mav.setViewName("/hp_auth_pop2");
				session.setAttribute(SESSION_ID.HP_AUTH_OK, "AUTH_OK");
				session.setAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT, "0");
				session.setAttribute(SESSION_ID.LOGIN_OK_FLAG, "3");
			}
			
		}catch (Exception e) {
			errorResult = "NG";
			errorMsg = MSGINFO.SMS_ERROR;
			try { usrLogger.error("mobileConfirmCheck_ajax|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		map.put("RESULT_KEY",errorResult);
		map.put("Message"   ,errorMsg);	
		return map;		
	}
	
	/**
	 * 휴대전화번호 인증화면 재전송 버튼 실행
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/mobileResend.do")
	public ModelAndView mobileConfirmResend(HttpServletRequest request) throws Exception {
		
		HttpSession session = request.getSession();
		String errorMsg = "";
		int errorResult = 1;		
		
		Logger usrLogger = UtilData.getLoggerInstance(session);
//		usrLogger.info("휴대전화번호 인증번호 재전송");
		
		try {
			//인증 체크 에러횟수 초기화
			session.setAttribute(SESSION_ID.SMS_AUTH_ERROR_COUNT, 0);
			
			String memberId = (String)session.getAttribute(SESSION_ID.USER_ID);		
			String handPhoneNo = (String)session.getAttribute(SESSION_ID.HANDPHONE_NO);			
				
			//휴대전화 인증 정보 등록
			boolean actionRst = mobileService.setMobileConfrimInfo(memberId,handPhoneNo);
			if (actionRst == false) {
				errorResult = -1;
				errorMsg = MSGINFO.SMS_SEND_ERROR;
			}		
			
		}catch (Exception e) {
			try { usrLogger.error("mobileConfirmResend|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}		
		
		//휴대전화 인증화면
		ModelAndView mav = new ModelAndView("/hp_auth_pop");		
		mav.addObject("errorResult", errorResult);
		mav.addObject("errormsg", errorMsg);
		return mav;		
	}
	
}