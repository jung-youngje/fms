package sdsi_tss.fms.web;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import sdsi_tss.fms.cmmn.CommonProperties.DOWNLOAD_INFO;
import sdsi_tss.fms.cmmn.CommonProperties.MSGINFO;
import sdsi_tss.fms.cmmn.CommonProperties.SESSION_ID;
import sdsi_tss.fms.cmmn.CommonProperties.VALUECONST;
import sdsi_tss.fms.cmmn.ConfigProperties;
import sdsi_tss.fms.cmmn.FilterUtil;
import sdsi_tss.fms.cmmn.UtilData;
import sdsi_tss.fms.service.CustUserVO;
import sdsi_tss.fms.service.DownloadService;
import sdsi_tss.fms.service.DownloadVO;

@Controller
public class DownloadController {

	@Resource(name = "downloadService")
	private DownloadService downloadService;

	/**
	 * �ٿ�ε� ȭ���� ǥ��
	 * 
	 * @param serviceKbn
	 * @param session
	 * @return
	 */
	@RequestMapping("/downloadview.do")
	public ModelAndView DownloadView(@RequestParam("service_kubun") String serviceKbn,
			HttpSession session) {

		ModelAndView mav = new ModelAndView();
		Logger usrLogger = UtilData.getLoggerInstance(session);
		String topPage = UtilData.makeTopPage(session);
		usrLogger.info("�ٿ�ε�ȭ�� Loading : /downloadview.do");
		
		serviceKbn = FilterUtil.getXSSFilter(serviceKbn);
		serviceKbn = FilterUtil.getSQLInjectionFilter(serviceKbn);
		
		try {
			String serviceName = serviceKubunMapping(serviceKbn);
			DownloadVO datavo = downloadService.XmlRead_DownLoadFileDesc(usrLogger, serviceName);

			if (datavo != null) {
				mav.addObject("windows_desc", datavo.getWindowFileDesc());
				mav.addObject("linux_desc", datavo.getLinuxFileDesc());
				mav.addObject("unix_desc", datavo.getUnixFileDesc());
				
				mav.addObject("windows_desc2", datavo.getWindowFileDesc2());
				mav.addObject("linux_desc2", datavo.getLinuxFileDesc2());
				mav.addObject("unix_desc2", datavo.getUnixFileDesc2());
			}
			
			mav.addObject("error", null);
			mav.addObject("status", null); 
			mav.addObject("service_kubun", serviceKbn);
			mav.addObject("service_cd", serviceKbn.replace("0", ""));
						
		}catch (Exception e) {
			try { usrLogger.error("DownloadView|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		mav.setViewName("/index");
		mav.addObject("top", topPage);
		mav.addObject("center", "download.jsp");

		usrLogger.info("�ٿ�ε�ȭ�� mav.getViewName() : " + mav.getViewName());
		return mav;
	}

	/**
	 * �ٿ�ε� ȭ�� -> �ٿ�ε� ��ư Ŭ��
	 * 
	 * @param DVO
	 * @param request
	 * @param session
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/download.do")
	//public ModelAndView download(@RequestParam("filedown") String filedown, DownloadVO DVO, HttpServletRequest request, HttpSession session) throws Exception {
	public ModelAndView download(DownloadVO DVO, HttpServletRequest request, HttpSession session)  {

		Logger usrLogger = UtilData.getLoggerInstance(session);
		usrLogger.info("�ٿ�ε� ��ưŬ�� action : /download.do");
		
		// ȸ������ ����
		String userId = session.getAttribute(SESSION_ID.USER_ID) != null ? session.getAttribute(SESSION_ID.USER_ID).toString() : "";
		// ȸ���̸� ����
		String userName = session.getAttribute(SESSION_ID.USER_NAME) != null ? session.getAttribute(SESSION_ID.USER_NAME).toString() : "";
		// �ڵ������� ����
		String hpAuthOk = session.getAttribute(SESSION_ID.HP_AUTH_OK) != null ? session.getAttribute(SESSION_ID.HP_AUTH_OK).toString() : "";
		// �޴���ȭ��ȣ ����
		String userCell = session.getAttribute(SESSION_ID.USER_CELL) != null ? session.getAttribute(SESSION_ID.USER_CELL).toString() : "";
		// ���� ���� CUST / VAN
		String userIdKubun= session.getAttribute(SESSION_ID.USERID_KUBUN) != null ? session.getAttribute(SESSION_ID.USERID_KUBUN).toString() : "";

		ModelAndView mav = new ModelAndView();		
		//CustUserVO cuv=new CustUserVO();
		
		DVO.setJob_name(serviceKubunMapping(DVO.getService_kubun()));
		DVO.setJob_type(osKindMapping(DVO.getOs_kubun()));
		DVO.setFile_type(fileKindMapping(DVO.getDownload_kubun()));
		usrLogger.info("job_name ["+DVO.getJob_name()+"] -- job_type ["+DVO.getJob_type()+"] -- file_type ["+DVO.getFile_type() + "]");	
		
		String serviceKbn = FilterUtil.getXSSFilter(DVO.getService_kubun());
		serviceKbn = FilterUtil.getSQLInjectionFilter(serviceKbn);
		DVO.setService_kubun(serviceKbn);
		
		String downloadKbn = FilterUtil.getXSSFilter(DVO.getDownload_kubun());
		downloadKbn = FilterUtil.getSQLInjectionFilter(downloadKbn);
		DVO.setDownload_kubun(downloadKbn);
		
		String osKbn = FilterUtil.getXSSFilter(DVO.getOs_kubun());
		osKbn = FilterUtil.getSQLInjectionFilter(osKbn);
		DVO.setOs_kubun(osKbn);
		
		try {
			// �ǽð�CMS, �ſ�ī���� install ������ �Ѱ� �� �� �߰� -> ���������� ������ ���� RCMS or CARD�� �ν�
			String ChgServiceKbn = "";
			if ("09".equals(DVO.getService_kubun())) {
				ChgServiceKbn = "02";
			} else if ("10".equals(DVO.getService_kubun())) {	
				ChgServiceKbn = "03";
			} else {
				ChgServiceKbn = DVO.getService_kubun();
			}
			
			String serviceName = serviceKubunMapping(ChgServiceKbn);
			DownloadVO datavo = downloadService.XmlRead_DownLoadFileDesc(usrLogger, serviceName);
	
			if (datavo != null) {
				mav.addObject("windows_desc", datavo.getWindowFileDesc());
				mav.addObject("linux_desc", datavo.getLinuxFileDesc());
				mav.addObject("unix_desc", datavo.getUnixFileDesc());
				
				mav.addObject("windows_desc2", datavo.getWindowFileDesc2());
				mav.addObject("linux_desc2", datavo.getLinuxFileDesc2());
				mav.addObject("unix_desc2", datavo.getUnixFileDesc2());
			}
			
			mav.addObject("service_kubun", ChgServiceKbn);
			mav.addObject("service_cd", ChgServiceKbn.replace("0", ""));
			
			// �α��ε� ȸ���� ���̵� �Է�
			DVO.setUser_id(userId);
			DVO.setUser_name(userName);
			// ȸ�������� ��ȭ��ȣ�� �Է�
			DVO.setUser_cell(userCell);			
			
			if (userId == "" && hpAuthOk == "") {
				// ��α���, �޴��������� �ٿ�ε� �Ұ���			
				mav.addObject("error", "logincell");
				mav.addObject("status", null); 
				restartMethod(mav,request,session);			
				usrLogger.info("�α��� �ʿ�");		
				return mav;
				
			}else if (userId != "" && hpAuthOk == "") {
				// �޴��������� �ٿ�ε� �Ұ���			
				mav.addObject("error", "cell");
				mav.addObject("status", null); 
				restartMethod(mav,request,session);	
				usrLogger.info("�α��� �ʿ�");
				return mav;
				
			}else {
			
				// ȸ�������� �Ǿ��ٸ�
				if (userId != "" && hpAuthOk != "") {
					if(userIdKubun != "" ){
						if(userIdKubun.equals(VALUECONST.USER_KUBUN_CUST)){// --�������� == CUST		
							 
							String chflag = ServiceflagCheck(usrLogger, userId, DVO.getJob_name());
							//ServiceType != Y : ERROR 
							if(!chflag.equals(VALUECONST.SERVICE_FLAG_Y)){
								mav.addObject("error", "user");
								mav.addObject("status", MSGINFO.PRE_MSG); //�����
								restartMethod(mav,request,session);
								usrLogger.info(userId+"��ü�� "+DVO.getJob_name()+"���� �����");
								return mav;
							}
						}
					}
					
					// �ش� ���̵��� �ٿ�ε� ���� ��ȸ
					String tryCnt = ConfigProperties.getProperty("download.try_cnt");					
					DownloadVO downloadCount =  downloadService.downloadCount(DVO);
					
					DownloadVO verinfo = downloadService.selectverinfo(DVO);
					if(verinfo!=null){
						DVO.setMajor_ver(verinfo.getMajor_ver());
						DVO.setMinor_ver(verinfo.getMinor_ver());
						DVO.setLast_version(verinfo.getLast_version());
						DVO.setAgent_pkg_name(verinfo.getAgent_pkg_name());
					}else{
						mav.addObject("error", "notupload");
						mav.addObject("status", MSGINFO.NO_SERVICE); //������
						restartMethod(mav,request,session);
						usrLogger.info("�ش缭�� "+DVO.getJob_name()+"-"+DVO.getJob_type()+"-"+DVO.getFile_type()+"�� ������");
						return mav;
					}
					
					// ���ϴٿ�ε�(file_name, filePathName set)
					fileDownLoad(DVO, mav, usrLogger); 
					
					if(downloadCount != null){						
						//<Modify AIT 2015-01-29 �ٿ�ε� Ƚ�� ���� 5ȸ->1ȸ�� ����> if (downloadCount.getDownload_cnt() >= 5) {
						usrLogger.info(downloadCount.getVersion()+"=="+verinfo.getLast_version());
						if (!downloadCount.getVersion().equals(verinfo.getLast_version())){
							usrLogger.info("---------���ο� �������� �ٿ�ε�---------");
							
							// ���� �ٿ�ε� ó��
							int downUpCnt = downloadService.downloadverUpdate(DVO); 
							
							// �ٿ�ε������� install �϶���
							if(DVO.getDownload_kubun().equals("I")){
								if(downUpCnt > 0){
									usrLogger.info("downinfo ������Ʈ ����\n");
									int disUpCnt = downloadService.distributeverUpdate(DVO);
									if(disUpCnt > 0){
										usrLogger.info("distribute ������Ʈ ����\n");
									}
								}
							}
						}else{
							if (downloadCount.getDownload_cnt() >=  Integer.parseInt(tryCnt)) {							
								// 5ȸ�̻� �ٿ�ε� �Ұ���
								mav.addObject("error", "number");
								mav.addObject("status", null); 
								restartMethod(mav,request,session);
								usrLogger.info("�ٿ�ε� Ƚ�� �ʰ� (" +tryCnt +"ȸ)" );
								return mav;
							}else{
								usrLogger.info("\n�������� ��ٿ�ε� ī��Ʈ +1 \n");
								downloadService.downloadUpdate(DVO);
							}
						}
					}else{ //������ ���� ��� insert ó��  
						//���� �ٿ�ε� ó��
						usrLogger.info("\n---------�ű� �ٿ�ε�---------");
						int downCnt = downloadService.downloadInsert(DVO);
						
						// �ٿ�ε������� install �϶���
						if(DVO.getDownload_kubun().equals("I")){
							if(downCnt > 0){
								usrLogger.info("downinfo Insert ����\n");
								int disCnt = downloadService.distributeInsert(DVO);  
								if(disCnt > 0){
									usrLogger.info("distribute Insert ����\n");
								}
							}
						}
					}
					
//					fileDownLoad(DVO, mav, usrLogger); 
				}
			}	
				
		}catch (Exception e ) {
			try { usrLogger.error("download|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		usrLogger.info("�ٿ�ε� ��ưŬ�� mav.getViewName() : " + mav.getViewName());
		return mav;		
	}
	
	/**
	 * �ش� ���� ��� ���� Ȯ�� 
	 * 
	 * @param usrLogger
	 * @param userId
	 * @param service_name
	 * @return
	 */
	public String ServiceflagCheck(Logger usrLogger, String userId, String service_name){
		
		usrLogger.info("���� ������� ServiceflagCheck");
		usrLogger.info("service_name ["+service_name+"]");
		
		String ch_result = "";
		List<CustUserVO> serviceList = downloadService.selectserviceflag(userId);
		
		for(int i=0; i < serviceList.size(); i++){
			CustUserVO cvo = serviceList.get(i);
			if(cvo.getService_type().equals(service_name)){
				ch_result=cvo.getService_flag();
				usrLogger.info("������ ���� flag : "+ch_result);
			}
		}
		
		return ch_result;
	}
	
	/**
	 * 
	 * @param DVO
	 * @param mav
	 * @param usrLogger
	 */
	private void fileDownLoad(DownloadVO DVO,ModelAndView mav, Logger usrLogger) {
		try {
			String serviceKbn = serviceKubunMapping(DVO.getService_kubun());
			String osKind = osKindMapping(DVO.getOs_kubun());
	
			// �ٿ�ε��� ���� ������ �̸��� ����		
			//String path="D:/Java/workspace/fmsWeb/src/main/webapp/download/";
			String filePathName = downloadService.XmlRead_DownLoadFile(serviceKbn, osKind, DVO.getDownload_kubun());
			int index = filePathName.lastIndexOf("/");
			
			DVO.setFile_name(filePathName.substring(index+1));
			
			// �ѱ�ó���� ����
			filePathName = new String(filePathName.getBytes("ISO-8859-1"), "euc-kr");		
			usrLogger.info("�ٿ�ε� ���� = " + filePathName);
	
			//���� �ٿ�ε� ���� ����
//			downloadService.downloadInfoSave(DVO);	 	
	
			// �������� �ٿ��Ͽ� ���� ��ü�� ����
			File downloadFile = new File(filePathName);
	
			mav.setViewName("downloadview");
			mav.addObject("downloadFile" , downloadFile );		
		
		}catch (IOException ie) {
			usrLogger.info("���� �ٿ�ε� ����");
			try { usrLogger.error("fileDownLoad|IOException", ie); } catch(Throwable ignore) {}
			ie.printStackTrace();
	    }
		catch (Exception e) {
			try { usrLogger.error("fileDownLoad|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
	}

	/**
	 * �ٿ�ε� ȭ�� Reload
	 * 
	 * @param mav
	 * @param request
	 * @param session
	 * @throws Exception
	 */
	private void restartMethod(ModelAndView mav,HttpServletRequest request,HttpSession session) throws Exception{
		String topPage = UtilData.makeTopPage(session);
		
		mav.setViewName("/index");
		mav.addObject("top", topPage);
		mav.addObject("center", "download.jsp");
	}

	/**
	 * ����&�������� �� >> ÷������ �ٿ�ε�
	 * 
	 * @param board_id
	 * @param filename
	 * @param service_name
	 * @param request
	 * @param session
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/noticeDownload.do")
	public ModelAndView noticeDownload(@RequestParam("board_id") String board_id,
			@RequestParam("filename") String filename,
			@RequestParam("service_name") String service_name,
			HttpServletRequest request, HttpSession session,
			HttpServletResponse response) throws Exception {
		
		Logger usrLogger = UtilData.getLoggerInstance(session);	
		usrLogger.info("����&�������� ÷������ �ٿ�ε� action : /noticeDownload.do");
		
		// �α��μ���
		String userId = (String) session.getAttribute(SESSION_ID.USER_ID);		
		ModelAndView mav = new ModelAndView();
		String topPage = UtilData.makeTopPage(session);
		
		filename = FilterUtil.getXSSFilter(filename);
		filename = FilterUtil.getSQLInjectionFilter(filename);
		
		board_id = FilterUtil.getXSSFilter(board_id);
		board_id = FilterUtil.getSQLInjectionFilter(board_id);
		
		if (service_name != null){
			service_name = FilterUtil.getXSSFilter(service_name);
			service_name = FilterUtil.getSQLInjectionFilter(service_name);
		}
		usrLogger.info("service_name value=" + service_name);
		
		String now_page = request.getParameter("now_page");
		if (now_page != null){
			now_page = FilterUtil.getXSSFilter(now_page);
			now_page = FilterUtil.getSQLInjectionFilter(now_page);
		}
		usrLogger.info("now_page value =" + now_page);
		
		try {
			if (userId != null) {			
				filename = new String(filename.getBytes("ISO-8859-1"), "euc-kr");
				
				// �ٿ�ε��� ���� ������ �̸��� ����
				//String path="C:/work/temp/boardfile/";
				String path = ConfigProperties.getProperty("download.attach_path");			
				String pathname = path + board_id +"/" + filename;
				
				usrLogger.info("÷������ �ٿ�ε� : " + pathname);
				
				// �������� �ٿ��Ͽ� ���� ��ü�� ����
				File downloadFile = new File(pathname);
				
				if(downloadFile.isFile() == false){
					mav.setViewName("/index");
					mav.addObject("top", topPage);
					mav.addObject("center", "notice_detail.jsp");
					mav.addObject("filedownfile", "nothing");
					mav.addObject("board_id", board_id);
					mav.addObject("service_name", service_name);
					return mav;
				}
								
				//response.setContentType("application/octet-stream;charset=utf-8");
			    //response.setHeader("Content-Disposition","attachment; filename=" + new String(downloadFile.getName().getBytes("8859_1"), "utf-8") + ";");
				
			    mav.setViewName("downloadview");				
				mav.addObject("downloadFile" , downloadFile);
				mav.addObject("service_name", service_name);
				
				usrLogger.info("����&�������� ÷������ �ٿ�ε� = " + downloadFile);
				
			}else{			
				mav.setViewName("/index");
				mav.addObject("top", topPage);
				mav.addObject("center", "notice_detail.jsp");
				mav.addObject("filedownlogin", "off");		
				mav.addObject("service_name", service_name);
			}
		}catch (Exception e) {
			try { usrLogger.error("noticeDownload|Exception", e); } catch(Throwable ignore) {}
			e.printStackTrace();
		}
		
		usrLogger.info("����&�������� ÷������ �ٿ�ε� mav.getViewName() : " + mav.getViewName());
		return mav;
	}
	
	/*
	private void updateMethod(DownloadVO DVO, ModelAndView mav, String hpAuthOk) throws Exception{
		// ȸ�������� ��ȭ��ȣ�� �Է�
		DVO.setUser_cell(hpAuthOk);

		// �ش� ���̵��� ������ ������ ������Ʈ�� ī��Ʈ+1
		downloadService.downloadUpdate(DVO);

		String serviceKbn = serviceKubunMapping(DVO.getService_kubun());
		String osKind = osKindMapping(DVO.getOs_kubun());

		// �ٿ�ε��� ���� ������ �̸��� ����		
		//String path="D:/Java/workspace/fmsWeb/src/main/webapp/download/";
		String filePathName = downloadService.XmlRead_DownLoadFile(serviceKbn, osKind, DVO.getDownload_kubun());

		// �ѱ�ó���� ����
		filePathName = new String(filePathName.getBytes("ISO-8859-1"), "euc-kr");
		
		// �������� �ٿ��Ͽ� ���� ��ü�� ����
		File downloadFile = new File(filePathName);

		mav.setViewName("downloadview");
		mav.addObject("downloadFile" , downloadFile );
	}*/

	/**
	 * ���񽺱��и� ���а����� ��ȯ (��: 01 -> BCMS)
	 * @param kbn
	 * @return
	 */
	private String serviceKubunMapping(String kbn){
		kbn = kbn.replace("'", "");
		String returnValue = "";

		if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_BCMS)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_BCMS;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_RCMS)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_RCMS;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_CARD)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_CARD;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_VIRTUAL)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_VIRTUAL;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_HP)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_HP;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_ARS)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_ARS;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_TAX)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_TAX;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_AUTH)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_AUTH;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_RCMSRW)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_RCMSRW;
			
		}else if (kbn.equals(DOWNLOAD_INFO.SERVICE_CODE_CARDAuth)){
			returnValue = DOWNLOAD_INFO.SERVICE_KUBUN_CARDAuth;
			
		}else {
			returnValue =  "";
		}
		
		return returnValue;		
	}

	/**
	 * OS������ ���а� �ؽ�Ʈ�� ��ȯ (��: 1 -> Windows)
	 * @param kbn
	 * @return
	 */
	private String osKindMapping(String kbn){
		if (kbn.equals(DOWNLOAD_INFO.OS_KIND_WINDOWS_VALUE)){
			return DOWNLOAD_INFO.OS_KIND_WINDOWS;
		}else if (kbn.equals(DOWNLOAD_INFO.OS_KIND_LINUX_VALUE)){
			return DOWNLOAD_INFO.OS_KIND_LINUX;
		}else if (kbn.equals(DOWNLOAD_INFO.OS_KIND_UNIX_VALUE)){
			return DOWNLOAD_INFO.OS_KIND_UNIX;
		}else {
			return  "";
		}				
	}
	
	private String fileKindMapping(String kbn){
		if (kbn.equals(DOWNLOAD_INFO.FILE_KIND_INSTALL)){
			return DOWNLOAD_INFO.FILE_KIND_I_VALUE;
		}else if (kbn.equals(DOWNLOAD_INFO.FILE_KIND_MANUAL)){
			return DOWNLOAD_INFO.FILE_KIND_M_VALUE;
		}else {
			return  "";
		}				
	}
	
}