/*
 * Copyright 2011 MOPAS(Ministry of Public Administration and Security).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package sdsi_tss.fms.mapper;

import java.util.List;

import org.mybatis.spring.annotation.MapperScan;

import sdsi_tss.fms.service.BoardFileVO;
import sdsi_tss.fms.service.NoticeVO;

@MapperScan("noticeMapper")
public interface NoticeMapper {

    Integer getNewscount() throws Exception;

	List<NoticeVO> getNewsList(NoticeVO searchVo) throws Exception;
	
	NoticeVO getNoticeInfo(NoticeVO noticeVo) throws Exception;

	List<NoticeVO> mainList() throws Exception;

	Integer getNoticecount(NoticeVO dataVo) throws Exception;

	List<NoticeVO> getNoticeList(NoticeVO dataVo) throws Exception;

	NoticeVO userInfo(NoticeVO dataVo) throws Exception;

	List<NoticeVO> getNoticeVanList(NoticeVO dataVo) throws Exception;

	Integer getNoticeVancount(NoticeVO dataVo) throws Exception;

	void getNoticeUpdate(NoticeVO dataVo) throws Exception;

	List<BoardFileVO> getFileDownload(NoticeVO dataVo) throws Exception;

}
