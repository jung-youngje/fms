package sdsi_tss.fms.mapper;

import org.mybatis.spring.annotation.MapperScan;

import sdsi_tss.fms.service.CustUserVO;
import sdsi_tss.fms.service.SwInfoVO;

@MapperScan("loginMapper")
public interface LoginMapper {

	public CustUserVO login(String login_id);
	public SwInfoVO van(String login_id);
}
