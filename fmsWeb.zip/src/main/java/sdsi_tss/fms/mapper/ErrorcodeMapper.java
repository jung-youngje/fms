
package sdsi_tss.fms.mapper;

import java.util.List;

import org.mybatis.spring.annotation.MapperScan;

import sdsi_tss.fms.service.ErrorcodeVO;

@MapperScan("errorcodeMapper")
public interface ErrorcodeMapper {

	Integer getCount() throws Exception;
	
	Integer getSelectCount(ErrorcodeVO selectError) throws Exception;
	
	List<ErrorcodeVO> getAllErrorList(ErrorcodeVO dataVo) throws Exception;	

	List<ErrorcodeVO> getSelectErrorlist(ErrorcodeVO selectError) throws Exception;

}
