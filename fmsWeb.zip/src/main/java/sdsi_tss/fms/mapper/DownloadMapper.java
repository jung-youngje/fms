
package sdsi_tss.fms.mapper;

import java.util.List;

import org.mybatis.spring.annotation.MapperScan;

import sdsi_tss.fms.service.CustUserVO;
import sdsi_tss.fms.service.DownloadVO;

@MapperScan("downloadMapper")
public interface DownloadMapper {

	DownloadVO downloadCount(DownloadVO DVO) throws Exception;
	
	DownloadVO selectverinfo(DownloadVO DVO) throws Exception;
	Integer downloadverUpdate(DownloadVO DVO) throws Exception;
	Integer distributeverUpdate(DownloadVO DVO) throws Exception;

	Integer downloadUpdate(DownloadVO DVO) throws Exception;	
	Integer downloadInsert(DownloadVO DVO) throws Exception;
	Integer distributeInsert(DownloadVO DVO) throws Exception;

	public List<CustUserVO> selectserviceflag(String login_id) ;
	
	public CustUserVO getCustUserServiceTypeBCMS(String login_id) ;
	
}
