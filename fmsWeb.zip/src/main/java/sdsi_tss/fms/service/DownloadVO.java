package sdsi_tss.fms.service;

import java.util.Date;

public class DownloadVO {
	
	public String windowFileDesc = "";	// ��������� ���� ����
	public String linuxFileDesc = "";		// �������� ���� ����
	public String unixFileDesc = "";		// ���н��� ���� ����
	
	// �ǽð�CMS, �ſ�ī���� ��� ������ �ΰ��� ����
	public String windowFileDesc2 = "";	// ��������� ���� ����
	public String linuxFileDesc2 = "";		// �������� ���� ����
	public String unixFileDesc2 = "";		// ���н��� ���� ����
	
	public String user_id = "";
	public String user_name = "";
	public String user_cell = "";
	public String service_kubun = "";
	public String os_kubun = "";
	public String download_kubun = "";
	public String file_name = "";
	public int download_cnt;
	public Date insert_dt;
	public Date update_dt;
	
	public String file = "";
	
	public String job_name = ""; 		// service_kubun
	public String job_type = ""; 		// os_kubun
	public String file_type = ""; 		// download_type
	public String version = ""; 		// version
	public String agent_pkg_name = "";
	public String last_version = "";
	public String major_ver = "";
	public String minor_ver = "";
	
	public DownloadVO() {
		super();
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_cell() {
		return user_cell;
	}

	public void setUser_cell(String user_cell) {
		this.user_cell = user_cell;
	}

	public String getService_kubun() {
		return service_kubun;
	}

	public void setService_kubun(String service_kubun) {
		this.service_kubun = service_kubun;
	}

	public String getOs_kubun() {
		return os_kubun;
	}

	public void setOs_kubun(String os_kubun) {
		this.os_kubun = os_kubun;
	}

	public String getDownload_kubun() {
		return download_kubun;
	}

	public void setDownload_kubun(String download_kubun) {
		this.download_kubun = download_kubun;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public int getDownload_cnt() {
		return download_cnt;
	}

	public void setDownload_cnt(int download_cnt) {
		this.download_cnt = download_cnt;
	}

	public Date getInsert_dt() {
		return insert_dt;
	}

	public void setInsert_dt(Date insert_dt) {
		this.insert_dt = insert_dt;
	}

	public Date getUpdate_dt() {
		return update_dt;
	}

	public void setUpdate_dt(Date update_dt) {
		this.update_dt = update_dt;
	}
	public String getJob_name() {
		return job_name;
	}

	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}

	public String getJob_type() {
		return job_type;
	}

	public void setJob_type(String job_type) {
		this.job_type = job_type;
	}

	public String getFile_type() {
		return file_type;
	}

	public void setFile_type(String file_type) {
		this.file_type = file_type;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getAgent_pkg_name() {
		return agent_pkg_name;
	}

	public void setAgent_pkg_name(String agent_pkg_name) {
		this.agent_pkg_name = agent_pkg_name;
	}

	public String getLast_version() {
		return last_version;
	}

	public void setLast_version(String last_version) {
		this.last_version = last_version;
	}

	public String getMajor_ver() {
		return major_ver;
	}

	public void setMajor_ver(String major_ver) {
		this.major_ver = major_ver;
	}

	public String getMinor_ver() {
		return minor_ver;
	}

	public void setMinor_ver(String minor_ver) {
		this.minor_ver = minor_ver;
	}

	/**
	 * @return ��������� ���� ����(ȭ�� ǥ��)
	 */
	public String getWindowFileDesc() {
		return windowFileDesc;
	}

	/**
	 * @param ��������� ���� ����(ȭ�� ǥ��) ����
	 */
	public void setWindowFileDesc(String windowFileDesc) {
		this.windowFileDesc = windowFileDesc;
	}

	/**
	 * @return �������� ���� ����(ȭ�� ǥ��)
	 */
	public String getLinuxFileDesc() {
		return linuxFileDesc;
	}

	/**
	 * @param �������� ���� ����(ȭ�� ǥ��) ����
	 */
	public void setLinuxFileDesc(String linuxFileDesc) {
		this.linuxFileDesc = linuxFileDesc;
	}

	/**
	 * @return ���н��� ���� ����(ȭ�� ǥ��)
	 */
	public String getUnixFileDesc() {
		return unixFileDesc;
	}

	/**
	 * @param ���н��� ���� ����(ȭ�� ǥ��) ����
	 */
	public void setUnixFileDesc(String unixFileDesc) {
		this.unixFileDesc = unixFileDesc;
	}

	public String getWindowFileDesc2() {
		return windowFileDesc2;
	}

	public void setWindowFileDesc2(String windowFileDesc2) {
		this.windowFileDesc2 = windowFileDesc2;
	}

	public String getLinuxFileDesc2() {
		return linuxFileDesc2;
	}

	public void setLinuxFileDesc2(String linuxFileDesc2) {
		this.linuxFileDesc2 = linuxFileDesc2;
	}

	public String getUnixFileDesc2() {
		return unixFileDesc2;
	}

	public void setUnixFileDesc2(String unixFileDesc2) {
		this.unixFileDesc2 = unixFileDesc2;
	}

	@Override
	public String toString() {
		return "DownloadVO [windowFileDesc=" + windowFileDesc
				+ ", linuxFileDesc=" + linuxFileDesc + ", unixFileDesc="
				+ unixFileDesc + ", user_id=" + user_id + ", user_name="
				+ user_name + ", user_cell=" + user_cell + ", service_kubun="
				+ service_kubun + ", os_kubun=" + os_kubun
				+ ", download_kubun=" + download_kubun + ", file_name="
				+ file_name + ", download_cnt=" + download_cnt + ", insert_dt="
				+ insert_dt + ", update_dt=" + update_dt + ", file=" + file
				+ ", job_name=" + job_name + ", job_type=" + job_type
				+ ", file_type=" + file_type + ", version=" + version
				+ ", agent_pkg_name=" + agent_pkg_name + ", last_version="
				+ last_version + ", major_ver=" + major_ver + ", minor_ver="
				+ minor_ver + "]";
	}
	
}