package sdsi_tss.fms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import sdsi_tss.fms.mapper.ErrorcodeMapper;
import sdsi_tss.fms.service.ErrorcodeService;
import sdsi_tss.fms.service.ErrorcodeVO;

@Service("erororcodeService")
public class ErrorcodServiceImpl implements ErrorcodeService {
	
	@Resource(name="errorcodeMapper")
	private ErrorcodeMapper errorcodeMapper;

	public Integer getCount() throws Exception {
		// TODO Auto-generated method stub
		return errorcodeMapper.getCount();
	}
	  

	public Integer getSelectCount(ErrorcodeVO selectError) throws Exception {
		// TODO Auto-generated method stub
		return errorcodeMapper.getSelectCount(selectError);
	}
	

	public List<ErrorcodeVO> getAllErrorlist(ErrorcodeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return errorcodeMapper.getAllErrorList(dataVo);
	}

	public List<ErrorcodeVO> getSelectErrorlist(ErrorcodeVO selectError)	throws Exception {
		// TODO Auto-generated method stub
		return errorcodeMapper.getSelectErrorlist(selectError);	
	}


}
