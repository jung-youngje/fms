package sdsi_tss.fms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import sdsi_tss.fms.mapper.NoticeMapper;
import sdsi_tss.fms.service.BoardFileVO;
import sdsi_tss.fms.service.NoticeService;
import sdsi_tss.fms.service.NoticeVO;

@Service("noticeService")
public class NoticeServiceImpl implements NoticeService {

    @Resource(name="noticeMapper")
	private NoticeMapper noticeMapper;
	
    public Integer getNewscount() throws Exception{
    	return noticeMapper.getNewscount();
    }
    
    public List<NoticeVO> getNewsList(NoticeVO searchVo) throws Exception{
		return noticeMapper.getNewsList(searchVo);
	}

	public NoticeVO getNoticeInfo(NoticeVO noticeVo) throws Exception {
		return noticeMapper.getNoticeInfo(noticeVo);
	}

	public List<NoticeVO> mainList() throws Exception { 
		return noticeMapper.mainList();
	}

	public Integer getNoticecount(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return noticeMapper.getNoticecount(dataVo);
	}

	public List<NoticeVO> getNoticeList(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return noticeMapper.getNoticeList(dataVo);
	}

	public NoticeVO userInfo(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return noticeMapper.userInfo(dataVo);
	}

	public List<NoticeVO> getNoticeVanList(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return noticeMapper.getNoticeVanList(dataVo);
	}

	public Integer getNoticeVancount(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return noticeMapper.getNoticeVancount(dataVo);
	}

	public void getNoticeUpdate(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		noticeMapper.getNoticeUpdate(dataVo);
		
	}

	public List<BoardFileVO> getFileDownload(NoticeVO dataVo) throws Exception {
		// TODO Auto-generated method stub
		return noticeMapper.getFileDownload(dataVo);
	}

	
}
