package sdsi_tss.fms.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;

import sdsi_tss.fms.cmmn.CommonProperties.DOWNLOAD_INFO;
import sdsi_tss.fms.cmmn.ConfigProperties;
import sdsi_tss.fms.mapper.DownloadMapper;
import sdsi_tss.fms.service.CustUserVO;
import sdsi_tss.fms.service.DownloadService;
import sdsi_tss.fms.service.DownloadVO;

@Service("downloadService")
public class DownloadServiceImpl implements DownloadService {
	/*
	 * @Autowired private Properties configProp;
	 * 
	 * @Value("#{configProp['download.xml_path']}") private String
	 * downloadXmlPath;
	 */
	@Resource(name = "downloadMapper")
	private DownloadMapper downloadMapper;

	public DownloadVO downloadCount(DownloadVO DVO) throws Exception {
		return downloadMapper.downloadCount(DVO);
	}

	public DownloadVO selectverinfo(DownloadVO DVO) throws Exception {
		return downloadMapper.selectverinfo(DVO);
	}

	public Integer downloadUpdate(DownloadVO DVO) throws Exception {
		return downloadMapper.downloadUpdate(DVO);
	}

	public Integer downloadverUpdate(DownloadVO DVO) throws Exception {
		return downloadMapper.downloadverUpdate(DVO);
	}

	public Integer distributeverUpdate(DownloadVO DVO) throws Exception {
		return downloadMapper.distributeverUpdate(DVO);
	}

	public Integer downloadInsert(DownloadVO DVO) throws Exception {
		return downloadMapper.downloadInsert(DVO);
	}

	public Integer distributeInsert(DownloadVO DVO) throws Exception {
		return downloadMapper.distributeInsert(DVO);
	}

	public List<CustUserVO> selectserviceflag(String login_id) {

		List<CustUserVO> returnVo = null;

		try {
			returnVo = downloadMapper.selectserviceflag(login_id);
		} catch (Exception e) {
		}

		return returnVo;
	}

	public boolean downloadInfoSave(DownloadVO DVO) {
		boolean returnValue = false;

		try {
			// �ش� ���̵��� ������ ������ ������Ʈ�� ī��Ʈ+1
			int update = downloadMapper.downloadUpdate(DVO);

			if (update == 0) {
				// �ش� ���̵��� �ٿ�ε����� �Է�
				int insert = downloadMapper.downloadInsert(DVO);
				if (insert < 1) {
					returnValue = false;
				} else {
					returnValue = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return returnValue;
	}

	/**
	 * ��ġCMS ���� Service_Type ���
	 * 
	 * @param login_id
	 * @return
	 */
	public CustUserVO getCustUserServiceTypeBCMS(String login_id) {
		CustUserVO returnVo = null;

		try {
			returnVo = downloadMapper.getCustUserServiceTypeBCMS(login_id);
		} catch (Exception e) {
		}

		return returnVo;
	}

	/**
	 * �ٿ�ε� ����� ȭ�� ����
	 */
	public DownloadVO XmlRead_DownLoadFileDesc(Logger usrLogger, String serviceKbn) throws Exception {
		
		System.out.println( "\n[XmlRead_DownLoadFileDesc]==============================================\n");
		DownloadVO returnVo = new DownloadVO();

		try {
			String downloadXmlPath = ConfigProperties.getProperty("download.xml_path");
			FileInputStream file = new FileInputStream(new File(downloadXmlPath));
			usrLogger.info("xml file path = " + downloadXmlPath);

			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			Document xmlDocument = builder.parse(file);

			XPath xPath = XPathFactory.newInstance().newXPath();

			// ��������� ����
			String w_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='WINDOWS']/desc";
			usrLogger.info("xml > windows desc = " + w_expression);
			returnVo.setWindowFileDesc(xPath.compile(w_expression).evaluate(xmlDocument));
			// xPath.compile(w_expression).evaluate(xmlDocument);

			// �������� ����
			String l_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='LINUX']/desc";
			usrLogger.info("xml > linux desc = " + l_expression);
			returnVo.setLinuxFileDesc(xPath.compile(l_expression).evaluate(xmlDocument));

			// ���н��� ����
			String u_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='UNIX']/desc";
			usrLogger.info("xml > unix desc = " + u_expression);
			returnVo.setUnixFileDesc(xPath.compile(u_expression).evaluate(xmlDocument));

			if("RCMS".equals(serviceKbn)) {
				usrLogger.info("serviceKbn == RCMS");
				// ��������� ����
				w_expression = "/support/service[@kubun='RCMSRW']/os[@kind='WINDOWS']/desc";
				usrLogger.info("xml > windows desc = " + w_expression);
				returnVo.setWindowFileDesc2(xPath.compile(w_expression).evaluate(xmlDocument));

				// �������� ����
				l_expression = "/support/service[@kubun='RCMSRW']/os[@kind='LINUX']/desc";
				usrLogger.info("xml > linux desc = " + l_expression);
				returnVo.setLinuxFileDesc2(xPath.compile(l_expression).evaluate(xmlDocument));

				// ���н��� ����
				u_expression = "/support/service[@kubun='RCMSRW']/os[@kind='UNIX']/desc";
				usrLogger.info("xml > unix desc = " + u_expression);
				returnVo.setUnixFileDesc2(xPath.compile(u_expression).evaluate(xmlDocument));
				
			}else if("CARD".equals(serviceKbn)) {
				usrLogger.info("serviceKbn == CARD");
				// ��������� ����
				w_expression = "/support/service[@kubun='CARDAuth']/os[@kind='WINDOWS']/desc";
				usrLogger.info("xml > windows desc = " + w_expression);
				returnVo.setWindowFileDesc2(xPath.compile(w_expression).evaluate(xmlDocument));
				
				// �������� ����
				l_expression = "/support/service[@kubun='CARDAuth']/os[@kind='LINUX']/desc";
				usrLogger.info("xml > linux desc = " + l_expression);
				returnVo.setLinuxFileDesc2(xPath.compile(l_expression).evaluate(xmlDocument));
				
				// ���н��� ����
				u_expression = "/support/service[@kubun='CARDAuth']/os[@kind='UNIX']/desc";
				usrLogger.info("xml > unix desc = " + u_expression);
				returnVo.setUnixFileDesc2(xPath.compile(u_expression).evaluate(xmlDocument));
				
			}
			
		} catch (IOException iex) {
			usrLogger.error("XmlRead_DownLoadFileDesc|IOException", iex);
//			throw new IOException(iex);

		} catch (Exception ex) {
			usrLogger.error("XmlRead_DownLoadFileDesc|Exception", ex);
//			throw new Exception(ex);
		}

		return returnVo;
	}

	/**
	 * �ٿ�ε� �н� + ���ϸ� ���
	 * 
	 * @param serviceKbn			���� CMS/BCMS ��
	 * @param osKind OS ����	Windows/Linux/Unix
	 * @param fileKind				���� ���� ��ġ����/�Ŵ���
	 */
	public String XmlRead_DownLoadFile(String serviceKbn, String osKind, String fileKind) throws Exception, IOException {

		String returnFileName = "";

		try {
			// FileInputStream file = new FileInputStream(new
			// File(DOWNLOAD_INFO.XML_PATH_DOWNLOAD));
			String downloadXmlPath = ConfigProperties.getProperty("download.xml_path");
			FileInputStream file = new FileInputStream(new File(downloadXmlPath));

			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			Document xmlDocument = builder.parse(file);
			XPath xPath = XPathFactory.newInstance().newXPath();

			String d_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='" + osKind + "']/filepath";
			String folder_Path = xPath.compile(d_expression).evaluate(xmlDocument);

			String f_expression = "";
			if (fileKind.equals(DOWNLOAD_INFO.FILE_KIND_INSTALL) == true) {
				f_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='" + osKind + "']/install_filename";
			} else {
				f_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='" + osKind + "']/manual_filename";
			}
			String fileName = xPath.compile(f_expression).evaluate(xmlDocument);
			returnFileName = ConfigProperties.getProperty("download.file_path") + folder_Path + fileName;

		} catch (IOException iex) {
			throw new IOException(iex);

		} catch (Exception ex) {
			System.out.println(ex);
			throw new Exception(ex);
		}

		return returnFileName;
	}

	public DownloadVO XmlRead_DownLoadFileDesc(String serviceKbn)
			throws Exception {
		return null;
	}

}