package sdsi_tss.fms.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import sdsi_tss.fms.mapper.LoginMapper;
import sdsi_tss.fms.service.CustUserVO;
import sdsi_tss.fms.service.LoginService;
import sdsi_tss.fms.service.SwInfoVO;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

    @Resource(name="loginMapper")
	private LoginMapper loginMapper;
    
    /**
     * ��ü���̵� �ش��ϴ� ���� ���� ���
     */
	public CustUserVO login(String login_id) {
		
		CustUserVO returnVo = null;
		
		try {
			returnVo = loginMapper.login(login_id);
		}catch (Exception e) {}
		
		return returnVo;
	}
	
	/**
	 * ���α׷����̵� �ش��ϴ� ���� ���� ���
	 */
	public SwInfoVO van(String login_id) {
		
		SwInfoVO returnVo = null;
		
		try {
			returnVo = loginMapper.van(login_id);
		}catch (Exception e) {}
		
		return returnVo;
	}
}
