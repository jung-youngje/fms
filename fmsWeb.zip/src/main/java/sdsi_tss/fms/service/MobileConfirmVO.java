package sdsi_tss.fms.service;

/**
 * 
 * �޴���ȭ ���� ����
 *
 */
public class MobileConfirmVO {
	String auth_id;
	String auth_tel;
	String auth_token;
	String auth_token_status;
	String auth_token_create_time;
	String insert_dt;
	String update_dt;
	String msg_id;
	
	public String getAuth_id() {
		return auth_id;
	}
	public void setAuth_id(String auth_id) {
		this.auth_id = auth_id;
	}
	public String getAuth_tel() {
		return auth_tel;
	}
	public void setAuth_tel(String auth_tel) {
		this.auth_tel = auth_tel;
	}
	public String getAuth_token() {
		return auth_token;
	}
	public void setAuth_token(String auth_token) {
		this.auth_token = auth_token;
	}
	public String getAuth_token_status() {
		return auth_token_status;
	}
	public void setAuth_token_status(String auth_token_status) {
		this.auth_token_status = auth_token_status;
	}
	public String getAuth_create_time() {
		return auth_token_create_time;
	}
	public void setAuth_create_time(String auth_create_time) {
		this.auth_token_create_time = auth_create_time;
	}
	public String getInsert_dt() {
		return insert_dt;
	}
	public void setInsert_dt(String insert_dt) {
		this.insert_dt = insert_dt;
	}
	public String getUpdate_dt() {
		return update_dt;
	}
	public void setUpdate_dt(String update_dt) {
		this.update_dt = update_dt;
	}
	
	
}
