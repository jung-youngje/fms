package sdsi_tss.fms.service;

import java.util.List;



public interface ErrorcodeService {

	Integer getCount() throws Exception;

	Integer getSelectCount(ErrorcodeVO selectError) throws Exception;
	
	List<ErrorcodeVO> getAllErrorlist(ErrorcodeVO dataVo) throws Exception;

	List<ErrorcodeVO> getSelectErrorlist(ErrorcodeVO selectError) throws Exception;

}
