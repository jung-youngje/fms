package sdsi_tss.fms.service;

import java.util.Date;

public class NoticeVO {

	String board_id = "";
	String start_dt = "";
	String end_dt = "";
	String target_service = "";
	String target_kind = "";
	String target_id = "";
	String subject = "";
	String content = "";
	String attachfile = "";
	int read_cnt;
	int down_cnt;
	String delete_flag = "";
	Date delete_dt;
	String insert_id = "";
	String update_id = "";
	Date insert_dt;
	Date update_dt;
	String pay_service = "";
	String pay_type = "";
	String adjust_type = "";
	String preface = "";
	String subject_emp = "";
	String emp_end = "";
	String point_file_id = "";
	String insertdt = "";

	// ����¡ó��
	int startRow;
	int endRow;

	// ��������
	String userId ="";

	// �Խô�� ����, ��������
	String service_cd ="";
	String charge_type ="";

	public String getCharge_type() {
		return charge_type;
	}

	public void setCharge_type(String charge_type) {
		this.charge_type = charge_type;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getService_cd() {
		return service_cd;
	}

	public void setService_cd(String service_cd) {
		this.service_cd = service_cd;
	}

	public String getBoard_id() {
		return board_id;
	}

	public void setBoard_id(String board_id) {
		this.board_id = board_id;
	}

	public String getStart_dt() {
		return start_dt;
	}

	public void setStart_dt(String start_dt) {
		this.start_dt = start_dt;
	}

	public String getEnd_dt() {
		return end_dt;
	}

	public void setEnd_dt(String end_dt) {
		this.end_dt = end_dt;
	}

	public String getTarget_service() {
		return target_service;
	}

	public void setTarget_service(String target_service) {
		this.target_service = target_service;
	}

	public String getTarget_kind() {
		return target_kind;
	}

	public void setTarget_kind(String target_kind) {
		this.target_kind = target_kind;
	}

	public String getTarget_id() {
		return target_id;
	}

	public void setTarget_id(String target_id) {
		this.target_id = target_id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getAttachfile() {
		return attachfile;
	}

	public void setAttachfile(String attachfile) {
		this.attachfile = attachfile;
	}

	public int getRead_cnt() {
		return read_cnt;
	}

	public void setRead_cnt(int read_cnt) {
		this.read_cnt = read_cnt;
	}

	public int getDown_cnt() {
		return down_cnt;
	}

	public void setDown_cnt(int down_cnt) {
		this.down_cnt = down_cnt;
	}

	public String getDelete_flag() {
		return delete_flag;
	}

	public void setDelete_flag(String delete_flag) {
		this.delete_flag = delete_flag;
	}

	public Date getDelete_dt() {
		return delete_dt;
	}

	public void setDelete_dt(Date delete_dt) {
		this.delete_dt = delete_dt;
	}

	public String getInsert_id() {
		return insert_id;
	}

	public void setInsert_id(String insert_id) {
		this.insert_id = insert_id;
	}

	public String getUpdate_id() {
		return update_id;
	}

	public void setUpdate_id(String update_id) {
		this.update_id = update_id;
	}

	public Date getInsert_dt() {
		return insert_dt;
	}

	public void setInsert_dt(Date insert_dt) {
		this.insert_dt = insert_dt;
	}

	public Date getUpdate_dt() {
		return update_dt;
	}

	public void setUpdate_dt(Date update_dt) {
		this.update_dt = update_dt;
	}

	public String getPay_service() {
		return pay_service;
	}

	public void setPay_service(String pay_service) {
		this.pay_service = pay_service;
	}

	public String getPay_type() {
		return pay_type;
	}

	public void setPay_type(String pay_type) {
		this.pay_type = pay_type;
	}

	public String getAdjust_type() {
		return adjust_type;
	}

	public void setAdjust_type(String adjust_type) {
		this.adjust_type = adjust_type;
	}

	public String getPreface() {
		return preface;
	}

	public void setPreface(String preface) {
		this.preface = preface;
	}

	public String getSubject_emp() {
		return subject_emp;
	}

	public void setSubject_emp(String subject_emp) {
		this.subject_emp = subject_emp;
	}

	public String getEmp_end() {
		return emp_end;
	}

	public void setEmp_end(String emp_end) {
		this.emp_end = emp_end;
	}

	public String getPoint_file_id() {
		return point_file_id;
	}

	public void setPoint_file_id(String point_file_id) {
		this.point_file_id = point_file_id;
	}

	public int getStartRow() {
		return startRow;
	}

	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}

	public int getEndRow() {
		return endRow;
	}

	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}

	public String getInsertdt() {
		return insertdt;
	}

	public void setInsertdt(String insertdt) {
		this.insertdt = insertdt;
	}

}