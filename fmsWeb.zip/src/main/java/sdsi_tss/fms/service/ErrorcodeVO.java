package sdsi_tss.fms.service;

import java.util.Date;

public class ErrorcodeVO {

	// ���̺�
	String payco_cd = "";
	String service_cd = "";
	String err_cd = "";
	String nh_err_cd = "";
	String err_msg1 = "";
	String err_msg2 = "";
	String origin_msg = "";
	String rsv = "";
	String insert_id = "";
	String update_id = "";
	Date insert_dt;
	Date update_dt;

	// �˻�����
	String sel_service_name = "";
	String sel_error_code = "";
	String txt_error_code = "";
	String txt_error_code1 = "";

	// ����¡
	int startRow;
	int endRow;

	// ORDERBY KBN
	String orderby_kbn = "";

	public String getPayco_cd() {
		return payco_cd;
	}

	public void setPayco_cd(String payco_cd) {
		this.payco_cd = payco_cd;
	}

	public String getService_cd() {
		return service_cd;
	}

	public void setService_cd(String service_cd) {
		this.service_cd = service_cd;
	}

	public String getErr_cd() {
		return err_cd;
	}

	public void setErr_cd(String err_cd) {
		this.err_cd = err_cd;
	}

	public String getNh_err_cd() {
		return nh_err_cd;
	}

	public void setNh_err_cd(String nh_err_cd) {
		this.nh_err_cd = nh_err_cd;
	}

	public String getErr_msg1() {
		return err_msg1;
	}

	public void setErr_msg1(String err_msg1) {
		this.err_msg1 = err_msg1;
	}

	public String getErr_msg2() {
		return err_msg2;
	}

	public void setErr_msg2(String err_msg2) {
		this.err_msg2 = err_msg2;
	}

	public String getOrigin_msg() {
		return origin_msg;
	}

	public void setOrigin_msg(String origin_msg) {
		this.origin_msg = origin_msg;
	}

	public String getRsv() {
		return rsv;
	}

	public void setRsv(String rsv) {
		this.rsv = rsv;
	}

	public String getInsert_id() {
		return insert_id;
	}

	public void setInsert_id(String insert_id) {
		this.insert_id = insert_id;
	}

	public String getUpdate_id() {
		return update_id;
	}

	public void setUpdate_id(String update_id) {
		this.update_id = update_id;
	}

	public Date getInsert_dt() {
		return insert_dt;
	}

	public void setInsert_dt(Date insert_dt) {
		this.insert_dt = insert_dt;
	}

	public Date getUpdate_dt() {
		return update_dt;
	}

	public void setUpdate_dt(Date update_dt) {
		this.update_dt = update_dt;
	}

	public String getSel_service_name() {
		return sel_service_name;
	}

	public void setSel_service_name(String sel_service_name) {
		this.sel_service_name = sel_service_name;
	}

	public String getSel_error_code() {
		return sel_error_code;
	}

	public void setSel_error_code(String sel_error_code) {
		this.sel_error_code = sel_error_code;
	}

	public String getTxt_error_code() {
		return txt_error_code;
	}

	public void setTxt_error_code(String txt_error_code) {
		this.txt_error_code = txt_error_code;
	}

	public int getStartRow() {
		return startRow;
	}

	public void setStartRow(int startRow) {
		this.startRow = startRow;
	}

	public int getEndRow() {
		return endRow;
	}

	public void setEndRow(int endRow) {
		this.endRow = endRow;
	}

	public String getTxt_error_code1() {
		return txt_error_code1;
	}

	public void setTxt_error_code1(String txt_error_code1) {
		this.txt_error_code1 = txt_error_code1;
	}

	public String getOrderby_kbn() {
		return orderby_kbn;
	}

	public void setOrderby_kbn(String orderby_kbn) {
		this.orderby_kbn = orderby_kbn;
	}

}
