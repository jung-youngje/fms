package sdsi_tss.fms.service;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

public interface DownloadService {

	DownloadVO downloadCount(DownloadVO DVO) throws Exception;
	DownloadVO selectverinfo(DownloadVO DVO) throws Exception;
	Integer downloadverUpdate(DownloadVO DVO) throws Exception;
	Integer distributeverUpdate(DownloadVO DVO) throws Exception;
 
	Integer downloadUpdate(DownloadVO DVO) throws Exception;
	Integer downloadInsert(DownloadVO DVO) throws Exception; 
	Integer distributeInsert(DownloadVO DVO) throws Exception;
	
	List<CustUserVO> selectserviceflag(String login_id);
//	CustUserVO getCustUserServiceTypeBCMS(String login_id);

	DownloadVO XmlRead_DownLoadFileDesc(Logger usrLogger, String serviceKbn) throws Exception;
	String XmlRead_DownLoadFile(String serviceKbn, String osKind, String fileKind) throws Exception,IOException;
	
	boolean downloadInfoSave(DownloadVO DVO);
	
}