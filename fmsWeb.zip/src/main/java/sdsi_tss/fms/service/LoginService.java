package sdsi_tss.fms.service;


public interface LoginService {

	CustUserVO login(String login_id);
	SwInfoVO van(String login_id);
}