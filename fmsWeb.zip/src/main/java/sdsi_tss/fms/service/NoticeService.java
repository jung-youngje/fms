package sdsi_tss.fms.service;

import java.util.List;


public interface NoticeService {

	Integer getNewscount() throws Exception;
	
	List<NoticeVO> getNewsList(NoticeVO searchVo) throws Exception;
	
	NoticeVO getNoticeInfo(NoticeVO noticeVo) throws Exception;

	List<NoticeVO> mainList() throws Exception;

	Integer getNoticecount(NoticeVO dataVo) throws Exception;

	List<NoticeVO> getNoticeList(NoticeVO dataVo) throws Exception;

	NoticeVO userInfo(NoticeVO dataVo) throws Exception;

	List<NoticeVO> getNoticeVanList(NoticeVO dataVo) throws Exception;

	Integer getNoticeVancount(NoticeVO dataVo) throws Exception;

	void getNoticeUpdate(NoticeVO dataVo) throws Exception;

	List<BoardFileVO> getFileDownload(NoticeVO dataVo) throws Exception;
	
}
