package sdsi_tss.fms.service;

public class CustUserVO{
	String nh_cust_no;
	String cust_id;
	String user_id;
	String user_pw;
	String user_nm;
	String dept_nm;
	String user_type;
	String delete_flag;
	String delete_dt;
	String user_tel;
	String user_cell;
	String user_fax;
	String user_email;
	String rsv;
	String insert_id;
	String update_id;
	String insert_dt;
	String update_dt;
	String init_yn;
	String last_login_dt;
	String fail_cnt;
	String pw_expire_dt;
	
	String cust_nm;
	String cust_status;
	String tax_status;
	
	String kubun;
	String service_type;
	String service_flag;
	
	public CustUserVO() {
		super();
	}

	public String getNh_cust_no() {
		return nh_cust_no;
	}

	public void setNh_cust_no(String nh_cust_no) {
		this.nh_cust_no = nh_cust_no;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_pw() {
		return user_pw;
	}

	public void setUser_pw(String user_pw) {
		this.user_pw = user_pw;
	}

	public String getUser_nm() {
		return user_nm;
	}

	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}

	public String getDept_nm() {
		return dept_nm;
	}

	public void setDept_nm(String dept_nm) {
		this.dept_nm = dept_nm;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public String getDelete_flag() {
		return delete_flag;
	}

	public void setDelete_flag(String delete_flag) {
		this.delete_flag = delete_flag;
	}

	public String getDelete_dt() {
		return delete_dt;
	}

	public void setDelete_dt(String delete_dt) {
		this.delete_dt = delete_dt;
	}

	public String getUser_tel() {
		return user_tel;
	}

	public void setUser_tel(String user_tel) {
		this.user_tel = user_tel;
	}

	public String getUser_cell() {
		return user_cell;
	}

	public void setUser_cell(String user_cell) {
		this.user_cell = user_cell;
	}

	public String getUser_fax() {
		return user_fax;
	}

	public void setUser_fax(String user_fax) {
		this.user_fax = user_fax;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getRsv() {
		return rsv;
	}

	public void setRsv(String rsv) {
		this.rsv = rsv;
	}

	public String getInsert_id() {
		return insert_id;
	}

	public void setInsert_id(String insert_id) {
		this.insert_id = insert_id;
	}

	public String getUpdate_id() {
		return update_id;
	}

	public void setUpdate_id(String update_id) {
		this.update_id = update_id;
	}

	public String getInsert_dt() {
		return insert_dt;
	}

	public void setInsert_dt(String insert_dt) {
		this.insert_dt = insert_dt;
	}

	public String getUpdate_dt() {
		return update_dt;
	}

	public void setUpdate_dt(String update_dt) {
		this.update_dt = update_dt;
	}

	public String getInit_yn() {
		return init_yn;
	}

	public void setInit_yn(String init_yn) {
		this.init_yn = init_yn;
	}

	public String getLast_login_dt() {
		return last_login_dt;
	}

	public void setLast_login_dt(String last_login_dt) {
		this.last_login_dt = last_login_dt;
	}

	public String getFail_cnt() {
		return fail_cnt;
	}

	public void setFail_cnt(String fail_cnt) {
		this.fail_cnt = fail_cnt;
	}

	public String getPw_expire_dt() {
		return pw_expire_dt;
	}

	public void setPw_expire_dt(String pw_expire_dt) {
		this.pw_expire_dt = pw_expire_dt;
	}
	
	public String getKubun() {
		return kubun;
	}

	public void setKubun(String kubun) {
		this.kubun = kubun;
	}

	public String getCust_nm() {
		return cust_nm;
	}

	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}

	public String getCust_status() {
		return cust_status;
	}

	public void setCust_status(String cust_status) {
		this.cust_status = cust_status;
	}
	

	public String getTax_status() {
		return tax_status;
	}

	public void setTax_status(String tax_status) {
		this.tax_status = tax_status;
	}

	public String getService_type() {
		return service_type;
	}

	public void setService_type(String service_type) {
		this.service_type = service_type;
	}

	public String getService_flag() {
		return service_flag;
	}

	public void setService_flag(String service_flag) {
		this.service_flag = service_flag;
	}

	@Override
	public String toString() {
		return "CustUserVO [nh_cust_no=" + nh_cust_no + ", cust_id=" + cust_id
				+ ", user_id=" + user_id + ", user_pw=" + user_pw
				+ ", user_nm=" + user_nm + ", dept_nm=" + dept_nm
				+ ", user_type=" + user_type + ", delete_flag=" + delete_flag
				+ ", delete_dt=" + delete_dt + ", user_tel=" + user_tel
				+ ", user_cell=" + user_cell + ", user_fax=" + user_fax
				+ ", user_email=" + user_email + ", rsv=" + rsv
				+ ", insert_id=" + insert_id + ", update_id=" + update_id
				+ ", insert_dt=" + insert_dt + ", update_dt=" + update_dt
				+ ", init_yn=" + init_yn + ", last_login_dt=" + last_login_dt
				+ ", fail_cnt=" + fail_cnt + ", pw_expire_dt=" + pw_expire_dt
				+ ", cust_nm=" + cust_nm + ", cust_status=" + cust_status
				+ ", tax_status=" + tax_status +", kubun=" + kubun + "]";
	}
}
