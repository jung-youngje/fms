package sdsi_tss.fms.service;

public class LoginVO {

	/*
	String member_id;
	String mobile_no;
	String email_addr;
	int downloadcnt;
	String name;
	
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getEmail_addr() {
		return email_addr;
	}
	public void setEmail_addr(String email_addr) {
		this.email_addr = email_addr;
	}
	public int getDownloadcnt() {
		return downloadcnt;
	}
	public void setDownloadcnt(int downloadcnt) {
		this.downloadcnt = downloadcnt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	*/
	
	String nh_cust_no;
	String cust_id;
	String cust_nm;
	String cust_status;
	
	public LoginVO() {
		super();
	}

	public String getNh_cust_no() {
		return nh_cust_no;
	}

	public void setNh_cust_no(String nh_cust_no) {
		this.nh_cust_no = nh_cust_no;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public String getCust_nm() {
		return cust_nm;
	}

	public void setCust_nm(String cust_nm) {
		this.cust_nm = cust_nm;
	}

	public String getCust_status() {
		return cust_status;
	}

	public void setCust_status(String cust_status) {
		this.cust_status = cust_status;
	}

	@Override
	public String toString() {
		return "LoginVO [nh_cust_no=" + nh_cust_no + ", cust_id=" + cust_id
				+ ", cust_nm=" + cust_nm + ", cust_status=" + cust_status + "]";
	}
	
}
