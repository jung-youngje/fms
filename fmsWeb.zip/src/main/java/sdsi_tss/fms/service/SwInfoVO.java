package sdsi_tss.fms.service;

public class SwInfoVO {
	String sw_id;
	String sw_nm;
	String service_yn;
	String user_tel;
	String user_cell;
	String user_email;
	String cms_service_yn;
	String real_service_yn;
	String virtual_service_yn;
	String mob_service_yn;
	String ars_service_yn;
	String cardauto_service_yn;
	String tax_service_yn;
	String auth_service_yn;
	
	String cust_id;
	
	String kubun;

	public SwInfoVO() {
		super();
	}

	public String getSw_id() {
		return sw_id;
	}

	public void setSw_id(String sw_id) {
		this.sw_id = sw_id;
	}

	public String getSw_nm() {
		return sw_nm;
	}

	public void setSw_nm(String sw_nm) {
		this.sw_nm = sw_nm;
	}

	public String getService_yn() {
		return service_yn;
	}

	public void setService_yn(String service_yn) {
		this.service_yn = service_yn;
	}

	public String getUser_tel() {
		return user_tel;
	}

	public void setUser_tel(String user_tel) {
		this.user_tel = user_tel;
	}

	public String getUser_cell() {
		return user_cell;
	}

	public void setUser_cell(String user_cell) {
		this.user_cell = user_cell;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getCms_service_yn() {
		return cms_service_yn;
	}

	public void setCms_service_yn(String cms_service_yn) {
		this.cms_service_yn = cms_service_yn;
	}

	public String getReal_service_yn() {
		return real_service_yn;
	}

	public void setReal_service_yn(String real_service_yn) {
		this.real_service_yn = real_service_yn;
	}

	public String getVirtual_service_yn() {
		return virtual_service_yn;
	}

	public void setVirtual_service_yn(String virtual_service_yn) {
		this.virtual_service_yn = virtual_service_yn;
	}

	public String getMob_service_yn() {
		return mob_service_yn;
	}

	public void setMob_service_yn(String mob_service_yn) {
		this.mob_service_yn = mob_service_yn;
	}

	public String getArs_service_yn() {
		return ars_service_yn;
	}

	public void setArs_service_yn(String ars_service_yn) {
		this.ars_service_yn = ars_service_yn;
	}

	public String getCardauto_service_yn() {
		return cardauto_service_yn;
	}

	public void setCardauto_service_yn(String cardauto_service_yn) {
		this.cardauto_service_yn = cardauto_service_yn;
	}

	public String getTax_service_yn() {
		return tax_service_yn;
	}

	public void setTax_service_yn(String tax_service_yn) {
		this.tax_service_yn = tax_service_yn;
	}

	public String getAuth_service_yn() {
		return auth_service_yn;
	}

	public void setAuth_service_yn(String auth_service_yn) {
		this.auth_service_yn = auth_service_yn;
	}

	public String getKubun() {
		return kubun;
	}

	public void setKubun(String kubun) {
		this.kubun = kubun;
	}
	
	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	@Override
	public String toString() {
		return "SwInfoVO [sw_id=" + sw_id + ", sw_nm=" + sw_nm
				+ ", service_yn=" + service_yn + ", user_tel=" + user_tel
				+ ", user_cell=" + user_cell + ", user_email=" + user_email
				+ ", cms_service_yn=" + cms_service_yn + ", real_service_yn="
				+ real_service_yn + ", virtual_service_yn="
				+ virtual_service_yn + ", mob_service_yn=" + mob_service_yn
				+ ", ars_service_yn=" + ars_service_yn
				+ ", cardauto_service_yn=" + cardauto_service_yn
				+ ", tax_service_yn=" + tax_service_yn + ", auth_service_yn="
				+ auth_service_yn + ", kubun=" + kubun + ", cust_id=" + cust_id
				+ "]";
	}
}
