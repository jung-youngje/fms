package sdsi_tss.fms.cmmn;

import java.io.File;
import java.io.FileInputStream;

import javax.xml.parsers.*;

import org.w3c.dom.*;

import sdsi_tss.fms.cmmn.CommonProperties.DOWNLOAD_INFO;
import sdsi_tss.fms.service.DownloadVO;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

public class UtilXmlParsing {
	
	public static void XmlRead() {
		try {
             //DOM Document ��ü �����ϱ� ���� �޼��� 
             DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
             //DOM �ļ��κ��� �Է¹��� ������ �Ľ��ϵ��� ��û
             DocumentBuilder parser = f.newDocumentBuilder();
             
             //XML ���� ����
             String url = "C:\\Work\\temp\\support\\down_info.xml";
             
             Document xmlDoc = null; 
             //DOM �ļ��κ��� �Է¹��� ������ �Ľ��ϵ��� ��û 
             xmlDoc = (Document) parser.parse(url);             
             
             //��Ʈ ������Ʈ ���� 
             Element root = (Element) xmlDoc.getDocumentElement();
             System.out.println(root.getTagName());    //booklist
             
             //���� ������Ʈ ����
             NodeList n1 = root.getElementsByTagName("service");
             Node bookNode = n1.item(0);
             Element bookElement = (Element)bookNode;
             
             
             //�Ӽ� ����
             String isbn = bookElement.getAttribute("kubun");
             System.out.println(isbn);    //B001
             
             //�ؽ�Ʈ (���) ����
             NodeList bookN1 = bookNode.getChildNodes();
             //�ε��� ���� ������ ��. 
             //����Ű�� �ش��ϴ� �κ��� ���� �� �ִ�.
             //(�� ��� ���ٴ�, getElementsByTagName() �� �̿��� �����ϴ°� ����.)
             Node titleNode = bookN1.item(1);
             Element titleElement = (Element)titleNode;
             System.out.println(titleElement.getTagName()); //title
             System.out.println(titleElement.getTextContent());    //�ڹ� ����
             
             //��ü ���
             //�Ӽ��� : isbn, kind
             //������Ʈ �ؽ�Ʈ �� : title, author, price
             System.out.println("------------------------------------------------------------------");
             for(int i=0; i<n1.getLength(); i++)
             {
                 Node bNode = n1.item(i);
                 Element bElement = (Element)bNode;
                 String is = bElement.getAttribute("isbn");
                 String ki = bElement.getAttribute("kind");
                 String title = bElement.getElementsByTagName("title").item(0).getTextContent();
                 String author = bElement.getElementsByTagName("author").item(0).getTextContent();
                 String price = bElement.getElementsByTagName("price").item(0).getTextContent();
                 String str = String.format("%8s %10s %20s %10s %8s", is, ki, title, author, price);
                 System.out.println(str);       
             }
             
        } catch(Exception e) {
            System.out.println(e.toString());
        }
	}

	/**
	 * �ٿ�ε� ����� ȭ�� ����
	 */
	public static DownloadVO XmlRead_DownLoadFileDesc(String serviceKbn){
		
		DownloadVO returnVo = new DownloadVO();
		
		try{
			String download_xmlPath = ConfigProperties.getProperty("download.xml_path");
			FileInputStream file = new FileInputStream(new File(download_xmlPath));
            
	        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();	             
	        DocumentBuilder builder =  builderFactory.newDocumentBuilder();	             
	        Document xmlDocument = builder.parse(file);	 
	        XPath xPath =  XPathFactory.newInstance().newXPath();
	        
	        //��������� ����
            String w_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='WINDOWS']/desc";
	        returnVo.setWindowFileDesc(xPath.compile(w_expression).evaluate(xmlDocument));
	       
	        //�������� ����
            String l_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='LINUX']/desc";
	        returnVo.setLinuxFileDesc(xPath.compile(l_expression).evaluate(xmlDocument));
	        
	        //���н��� ����
            String u_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='UNIX']/desc";
	        returnVo.setUnixFileDesc(xPath.compile(u_expression).evaluate(xmlDocument));

	        /*
	       //read an xml node using xpath
	       Node node = (Node) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODE);
	        
	       //read a nodelist using xpath
	       NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(xmlDocument, XPathConstants.NODESET);
	       for(int i = 0; i < nodeList.getLength(); i++){
	            System.out.println(nodeList.item(i).getNodeValue());
	         }
			*/
	      }catch(Exception ex){
	         System.out.println(ex);
	      }      
		
		return returnVo;
	}
	
	/**
	 *  �ٿ�ε� �н� + ���ϸ� ���
	 *  @param serviceKbn  ���� CMS/BCMS ��
	 *  @param osKind      OS ���� Windows/Linux/Unix 
	 *  @param fileKind      ���� ���� ��ġ����/�Ŵ���
	 */
	public static String XmlRead_DownLoadFile(String serviceKbn, String osKind, String fileKind){
		
		String returnFileName ="";
		
		try{
			String download_xmlPath = ConfigProperties.getProperty("download.xml_path");
			FileInputStream file = new FileInputStream(new File(download_xmlPath));
            
	        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();	             
	        DocumentBuilder builder =  builderFactory.newDocumentBuilder();	             
	        Document xmlDocument = builder.parse(file);	 
	        XPath xPath =  XPathFactory.newInstance().newXPath();
	        
            String d_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='" + osKind + "']/filepath";
	        String folder_Path = xPath.compile(d_expression).evaluate(xmlDocument);
	        
	        String f_expression = "";
	        if (fileKind.equals(DOWNLOAD_INFO.FILE_KIND_INSTALL) == true) {	        
	        	f_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='" + osKind + "']/install_filename";
	        } else {
	        	f_expression = "/support/service[@kubun='" + serviceKbn + "']/os[@kind='" + osKind + "']/manual_filename";
	        }
	        String fileName =  xPath.compile(f_expression).evaluate(xmlDocument);
	        
	        returnFileName = folder_Path + fileName;

	      }catch(Exception ex){
	         System.out.println(ex);
	      }      
		
		return returnFileName;
	}
}
