package sdsi_tss.fms.cmmn;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ConfigProperties {

	private static Properties configProp;
	
	@Autowired 
	public void setConfigProp(Properties configProp) {
		ConfigProperties.configProp = configProp;
	}

	public static String getProperty(String key) {
	        return configProp.getProperty(key);
    }
}
