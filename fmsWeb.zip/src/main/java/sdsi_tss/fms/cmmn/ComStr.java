/*------------------------------------------------------------------------------
 * comStr.java
 * uTour, Version 1.0
 * 
 * Copyright rights reserved.
 *(c) 2009-2010 uTour.,
 * uTour * All 
 *----------------------------------------------------------------------------*/
package sdsi_tss.fms.cmmn;

import java.util.ArrayList;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * STRING��ȯ Class
 *  
 * @author jssong
 */
public class ComStr {
//	private static Log logger			=	LogFactory.getLog(ComStr.class.getClass());
	
//	private static String CRLF = System.getProperty("line.separator");
	private static String[] nlTags = { "P", "CENTER", "HR", "BR", "LI",
		   "UL", "/UL", "OL",  "/OL", 
		   "TABLE", "/TABLE", "/TR",
		   "META", "BODY", "/BODY", "/HTML",
		   "/HEAD", "/TITLE" };

	//�Ϲ� Result Code ����
	public static final String SECURITY_KEY		  = "KEBTBASE";
	
	
	/**
	 * ������
	 */
	public ComStr() {
		
	}
	
    /**
     * ������ Ư�� ���� ���� �ϱ�
     * @param str
     * @param delChar
     * @return String
     */
    public static String delRightChar(String str, char delChar) {
        String value = str;

        while (value.length() > 0) {
            int i = value.length() - 1;
            if (value.charAt(i) == delChar) {
                value = value.substring(0, i);
            } else
                break;
        }
        return value;
    }
    
    /**
     * NULL�� ó��
     * @param strTarget
     * @return String
     */
    public static String getNullConv(String strTarget) {
    	return getNullConv(strTarget, "");
    }

    /**
     * NULL�� ó��
     * @param strTarget
     * @param strConv
     * @return String
     */
    public static String getNullConv(String strTarget, String strConv) {
    	String szTemp;

    	if(strConv == null)	strConv = "";

    	if(strTarget == null || "".equals(strTarget) || "null".equals(strTarget)) {
    		szTemp = strConv;
    	} else {
    		szTemp = strTarget;
    	}
    	
    	//szTemp 		= szTemp.replace("'", "��");
    	//szTemp  	= szTemp.replace("\"","��");
    	//szTemp  	= szTemp.replace("<","&lt;");
    	//szTemp  	= szTemp.replace(">","&gt;");
    	
    	return szTemp;
    }
    
    /**
     * TEXTAREA �� NULL�� ó��
     * @param strTarget
     * @param strConv
     * @return String
     */
    public static String getNullConvTextarea(String strTarget) {
    	return getNullConvTextarea(strTarget, "");
    }
    
    /**
     * TEXTAREA �� NULL�� ó��
     * @param strTarget
     * @param strConv
     * @return String
     */
    public static String getNullConvTextarea(String strTarget, String strConv) {
    	String szTemp;

    	if(strConv == null)	strConv = "";

    	if(strTarget == null || "".equals(strTarget) || "null".equals(strTarget)) {
    		szTemp = strConv;
    	} else {
    		szTemp = strTarget;
    	}
    	
    	return szTemp;
    }

    /**
     * NULL�� ó��
     * @param strTarget
     * @param intConv
     * @return Integer
     */
    public static int intNullChk(String strTarget, int intConv) {
        int returnValue = 0;


        if (strTarget == null || ("").equals(strTarget.trim()) || ("null").equals(strTarget))
                returnValue = intConv;
        else returnValue = Integer.parseInt(strTarget.trim());

        return returnValue;
    }

    
    /**
     * Ư�� ���� ġȯ
     * @param str
     * @param index_str
     * @param new_str
     * @return String
     */
    public static String getChangeString(String str, String index_str, String new_str) {
        String temp = "";
        if (str != null && str.indexOf(index_str) != -1) {
            while (str.indexOf(index_str) != -1) {
                temp = temp + str.substring(0, str.indexOf(index_str)) + new_str;
                str = str.substring(str.indexOf(index_str) + index_str.length());
            }
            temp = temp + str;
        } else {
            temp = str;
        }

        return temp;
    }
    
    /**
     * ������ ���� ���� ����
     * @param  str
     * @return String
     */ 
    public static String rightTrim(String str) {
        if (str == null || str.equals(""))
          return str;

        int i;
        int len = str.length();

        for (i = 0; i < len; i++) {
          if (str.charAt(len - i - 1) != ' ')
            break;
        }

        return str.substring(0, len - i);
      }
    
    /**
     * ","�� �������� �迭�� ������ ��ȯ(split)
     * @param  str
     * @return String[]
     */
    public static String[] strArrToken(String str) {
		return strArrToken(str, ",");
	}

	/**
	 * Ư�� ���ڸ� �������� �迭�� ������ ��ȯ(split)
	 * @param  str
	 * @param  delemiter
	 * @return String[]
	 */
	public static String[] strArrToken(String str, String delemiter) {
		StringTokenizer	token			=	new StringTokenizer(str, delemiter);
		StringBuffer	temp			=	new StringBuffer();
		int		cnt						=	token.countTokens();
		String	strArr[]				=	new String[cnt];

		for(int i=0; i<cnt; i++) {
			strArr[i]					=	token.nextToken();
			temp.append(strArr[i]);
		}

		return strArr;
	}
	
	/**
     * SPLIT�Լ�
     * @param  text
     * @param  splitword
     * @return String []
     */
    public static String [] StringSplit(String text, String splitword)
	{
		StringTokenizer oToken = new StringTokenizer(text, splitword);
		
		String [] strarrReturn = new String[oToken.countTokens()];
		
		for(int i=0; i<strarrReturn.length; i++)
		{
			strarrReturn[i] = oToken.nextToken();
		}
		
		return strarrReturn;
	}
    
    /**
     * STRING���� �ش� STRING ���� ����
     * @param  strParam
     * @param  strNotWord
     * @return String
     */
    public static String removeParam(String strParam, String strNotWord) {
        String strRetVal = "";
        
        try {
	        if (strParam == null   || "".equals(strParam )) return  "";
	        if (strNotWord == null || "".equals(strNotWord )) return "";
	        
	        int iStartPos = indexOfaA(strParam, strNotWord, 0);
	     
	        if ( iStartPos < 0 ) return  strParam;
	        
	        int iEndPos = indexOfaA(strParam, "&", iStartPos);
	         
	        if ( iEndPos <= 0) iEndPos = strParam.length() -1 ;
	        strRetVal = strParam.substring(0, iStartPos) + strParam.substring(iEndPos+1);
        } catch (Exception e){
            System.out.println("CommonUtil[removeParam]=>" + e.toString() );
        }
        return strRetVal ;
        
    }
    
    /**
     * String���� �ش� INDEX���� ��ȯ
     * @param  str
     * @param  indexstr
     * @param  fromindex
     * @return int
     */
    public static int indexOfaA(String str, String indexstr, int fromindex) {
        int index = 0;
        indexstr = indexstr.toLowerCase();
        str = str.toLowerCase();
        index = str.indexOf(indexstr, fromindex);
        return index;
    }
    
    /**
     * getConv �����Ѵ�
     * @param  objKey
     * @return getConv
     */
    public static String getConv(Object objKey ) {
        
        return getConv(objKey, "" );
    }      
    
    /**
     * Object�� String ���� ��ȯ�Ѵ�
     * @param  objKey
     * @param  strVal
     * @return String
     */
    public static String getConv(Object objKey , String strVal) {
        if (objKey != null && !objKey.equals("null")) {
            String strKey = objKey.toString().trim();
           
           if (!"".equals(strKey)) return strKey;
        }
        return strVal;
    }
    
    public static boolean getLangComp(ArrayList arrlang, String langtype) {
    	
    	boolean		resultval 				= false;
    	for(int i = 0; i < arrlang.size(); i++) {
    	    Map lstUserLanguageRow = (Map)arrlang.get(i);
    	           
    	    if(langtype.equals(lstUserLanguageRow.get("COM_SYS_VALUE"))) {
    	    	resultval = true;
    	    	break;
    	    }
    	}
    	
    	return resultval;
    	
    }
    
    
    /**
	 * �±� ���� �Լ� 
	 * @param souceStr: ���� ���ڿ� 
	 * @return
	 */
	public static String removeHtmlTag(String souceStr) {
		final int NORMAL_STATE = 0;
		final int TAG_STATE = 1;
		final int START_TAG_STATE = 2;
		final int END_TAG_STATE = 3;
		final int SINGLE_QUOT_STATE = 4;
		final int DOUBLE_QUOT_STATE = 5;
		int state = NORMAL_STATE;
		int oldState = NORMAL_STATE;
		char[] chars = souceStr.toCharArray();
		StringBuffer sb = new StringBuffer();
		boolean bSlash = false;
		String tagWord = "";
		boolean tagWordDone = false;
		char a;
		for (int i = 0; i < chars.length; i++) {
			a = chars[i];
			switch (state) {
				case NORMAL_STATE:
					if (a == '<') {
						tagWord = "";
						state = TAG_STATE;
					}
					else
						sb.append(a);
					break;
				case TAG_STATE:
					if (a == '>')
						state = NORMAL_STATE;
					else if (a == '\"') {
						oldState = state;
						state = DOUBLE_QUOT_STATE;
					}
					else if (a == '\'') {
						oldState = state;
						state = SINGLE_QUOT_STATE;
					}
					else if (a == '/') {
						tagWord = "" + a;
						tagWordDone = false;
						state = END_TAG_STATE;
					}
					else if (a != ' ' && a != '\t' && a != '\n' && a != '\r' && a != '\f') {
						tagWord = "" + a;
						tagWordDone = false;
						state = START_TAG_STATE;
					}
					break;
				case START_TAG_STATE:

				case END_TAG_STATE:
					if (a == '>') {
						if (isNewLineTag(tagWord)) {
							//sb.append(CRLF);                        
						}
						state = NORMAL_STATE;
					}
					else if (a == '\"') {
						oldState = state;
						state = DOUBLE_QUOT_STATE;
					}
					else if (a == '\'') {
						oldState = state;
						state = SINGLE_QUOT_STATE;
					}
					else if (a == ' ' || a == '\t' || a == '\n' || a == '\r' || a == '\f') {
						tagWordDone = true;
					}
					else if (!tagWordDone) {
						tagWord += a;
					}
					break;

				case DOUBLE_QUOT_STATE:
					if (bSlash)
						bSlash = false;
					else if (a == '\"')
						state = oldState;
					else if (a == '\\')
						bSlash = true;
					break;
				case SINGLE_QUOT_STATE:
					if (bSlash)
						bSlash = false;
					else if (a == '\'')
						state = oldState;
					else if (a == '\\')
						bSlash = true;
					break;
			}
		}
		String tmpStr = sb.toString();
		if(tmpStr!=null){
			tmpStr = replaceStr(tmpStr,"&nbsp;","");
		}
		return tmpStr;
	}		
	
	public static boolean isNewLineTag(String s) {
		if (s == null)
			return false;
		String str = allTrim(s);
		for (int i = 0; i < nlTags.length; i++) {
			if (str.equalsIgnoreCase(nlTags[i]))
				return true;
		}
		return false;
	}
	
	/**
	 * ���ڿ� ġȯ �Լ� 
	 * @param sourceStr: ���� ���ڿ�
	 * @param oldStr: ã�� ���ڿ� 
	 * @param newStr: ġȯ�� ���ڿ� 
	 * @return oldStr�� newStr�� ġȯ�� String�� ����
	 */
	public static String replaceStr(String sourceStr, String oldStr, String newStr){
		int s = 0;
		int e = 0;
		
		if(sourceStr!=null){		
			StringBuffer result = new StringBuffer();
	
			while ((e = sourceStr.indexOf(oldStr, s)) >= 0) {
				result.append(sourceStr.substring(s, e));
				result.append(newStr);
				s = e + oldStr.length();
			}
			result.append(sourceStr.substring(s));
			return result.toString();
		}else
			return "";
	} 	
	
	public static String allTrim(String s) {
		if (s == null)
			return null;
		else if (s.length() == 0)
			return "";

		int len = s.length();
		int i = 0;
		int j = len - 1;

		for (i = 0; i < len; i++) {
			if ( s.charAt(i) != ' ' && s.charAt(i) != '\t'
									&& s.charAt(i) != '\r'
									&& s.charAt(i) != '\n' )
				break;
		}
		if (i == len)
			return "";

		for (j = len - 1; j >= i; j--) {
			if ( s.charAt(i) != ' ' && s.charAt(i) != '\t'
									&& s.charAt(i) != '\r'
									&& s.charAt(i) != '\n' )
				break;
		}
		return s.substring(i, j + 1);
	}	
	
	/**
	 * ���ڿ��� ������ ���̿��� �ڸ���, �ʰ��� ��� "..."�� ���� 
	 * @param souceStr: ���� ���ڿ�
	 * @param byteLen: ����Ʈ ��
	 * @return
	 * @throws Exception
	 */
	public static String getCutStr(String souceStr, int byteLen) throws Exception{
		String szLeft = trim(souceStr);
		int nszLeft = szLeft.length();
		for(int i = 1; i <= nszLeft; i++){
			szLeft = souceStr.substring(0, i);
			if(getStrLen(szLeft) <= byteLen)
				continue;
			szLeft = souceStr.substring(0, i - 1);
			szLeft = szLeft + "...";
			break;
		}
		return szLeft;
	}	
	
	/**
	 * �������ڿ��� null�� �ƴ� ��� trim()������ ����
	 * (null�� ��� ""�� ���ϵ�)
	 * @param tmpStr
	 * @return
	 * @throws Exception
	 */	
	public static String trim(String tmpStr) throws Exception{
		if(tmpStr!=null)
			return tmpStr.trim();
		else
			return "";
	}
	
	/**
	 * ���ڿ��� byte���� ����
	 * @param sourceStr: �������ڿ� 
	 * @return
	 * @throws Exception
	 */
	public static int getStrLen(String sourceStr) throws Exception{
		int nLen = 0;
		sourceStr = trim(sourceStr);
		for(int i = 0; i < sourceStr.length(); i++){
			char szEach = sourceStr.charAt(i);
			if('\0' <= szEach && szEach <= '\377')
				nLen++;
			else
				nLen += 2;
		}
		return nLen;
	}
	/**
	 * �迭(���ڿ�)�� ���ڷ� ��ȯ
	 * @param sourceStr: �������ڿ� 
	 * @return
	 * @throws Exception
	 */
	public static String getArrayToStr(String[] sourceStr, String delim) throws Exception{
		StringBuffer sbRtn = new StringBuffer();
		String strDeli = delim;
		
		if (strDeli.length() < 1) {strDeli = ",";}
		
		if (sourceStr.length > 0){sbRtn.append(sourceStr[0]);}
		
		for(int i = 1; i < sourceStr.length; i++){
			sbRtn.append(strDeli).append(sourceStr[i]);
		}
		return sbRtn.toString();
	}
	
	
	
	/**
     * ORACLE CLOB�ʵ带 String ���� ��ȯ
     * @param clob
     * @return String
     */
/*
	public static String getStringForCLOB(CLOB clob) {
        StringBuffer sbf = new StringBuffer();
        Reader br = null;
        char[] buf = new char[1024];
        int readcnt;

        try {
            br = clob.getCharacterStream(0L);

            while ((readcnt=br.read(buf,0,1024))!=-1) {
                sbf.append(buf,0,readcnt);
            }

        } catch (Exception e) {
        	System.out.println("CommonUtil getStringForCLOB()" + e.toString());
            return null;

        }finally{
            if(br!=null)
                try {
                    br.close();
                } catch (IOException e) {
                	System.out.println("CommonUtil getStringForCLOB()" + e.toString());
                    return null;

               }
        }
        return sbf.toString();
    }
*/    
}