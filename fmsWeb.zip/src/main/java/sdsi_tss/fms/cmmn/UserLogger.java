package sdsi_tss.fms.cmmn;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.varia.LevelRangeFilter;
import org.slf4j.MDC;

public class UserLogger {
	
	private final static String DEFAULT_LOG_PATTERN	= "[%p] [%d{yyyy-MM-dd HH:mm:ss}] - %m%n";
	private final static Level  DEFAULT_LOG_LEVEL		= Level.INFO;
	private final static String DEFAULT_LOG_DIR			= ConfigProperties.getProperty("log.site_log_path");
	private final static String DEFAULT_DATEPATTERN	= "yyyyMMdd";
	private final static String UNKNOWN_USERID			= "UNKNOWN";
	
	public static Logger getLogger(String userId) {
		if( null == userId || "".equals(userId) ) {
			userId = UNKNOWN_USERID;
		}
		MDC.put("userId", userId);
		
	    Logger logger = Logger.getLogger(UserLogger.class.getName() + "." + userId);
	    Appender appender = logger.getAppender("USERFILEAPPENDER");
	    
	    if( null == appender ) {
	    	PatternLayout patternLayout = new PatternLayout();
	    	patternLayout.setConversionPattern(DEFAULT_LOG_PATTERN);
	
	    	LevelRangeFilter filter = new LevelRangeFilter();
	    	filter.setLevelMin(DEFAULT_LOG_LEVEL);
	
	    	{
				UserDailyRollingFileAppender userFileAppender = new UserDailyRollingFileAppender();
				userFileAppender.setName("USERFILEAPPENDER");
				userFileAppender.setLayout(patternLayout);
				userFileAppender.addFilter(filter);
				userFileAppender.setFile(DEFAULT_LOG_DIR + "/{datePattern}/{userId}.log");
				userFileAppender.setAppend(true);
				userFileAppender.setDatePattern(DEFAULT_DATEPATTERN);
		        userFileAppender.setUserId(userId);
		        userFileAppender.activateOptions();
		
		        logger.addAppender(userFileAppender);
	    	}
	    	{
	    		ConsoleAppender consoleAppender = new ConsoleAppender();
	    		consoleAppender.setName("CONSOLE");
	            consoleAppender.setLayout(patternLayout);
	            consoleAppender.addFilter(filter);
	            consoleAppender.activateOptions();

	            logger.addAppender(consoleAppender);
	        }
	    }
	    
	    return logger;
	}
	
	public static Logger getLogger() {
		return getLogger(null);
	}
	
	static class LogTestThread extends Thread {
		private String userId;
		public LogTestThread(String userId) {
			this.userId = userId;
		}
	
		private void zzz(int count) {
			Logger logger = getLogger(userId);
			logger.info(Thread.currentThread().getName() + "|" + userId + "|zzzzzzzzzzzzzzzzz " + count++);
		}
		
		@Override
		public void run() {
			Logger logger = getLogger(userId);
			logger.info(userId + "| thread start");
		
			int        count = 0;
			try {
				while(true) {
					zzz(count++);
					Thread.sleep(500);
				}
			} catch (Exception e) {
				logger.error("exception", e);
			}
			logger.info(userId + "| thread end");
		}
	}
	
	public static void main(String[] args) {
		LogTestThread[] threads = new LogTestThread[10];
		for (int i = 0; i < threads.length; i++) {
			threads[i] = new LogTestThread("user-" + i);
		}
	
		for (int j = 0; j < threads.length; j++) {
			threads[j].start();
		}
	
		try {
			for (int j = 0; j < threads.length; j++) {
			threads[j].join();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}