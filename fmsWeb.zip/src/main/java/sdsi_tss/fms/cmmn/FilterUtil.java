package sdsi_tss.fms.cmmn;

import java.util.regex.Pattern;

public class FilterUtil {
	
	public static String getXSSFilter(String sInvalid) {
		
		String sValid = sInvalid;
		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}

		sValid = sValid.replaceAll("&", "&amp;");
		sValid = sValid.replaceAll("<", "&lt;");
		sValid = sValid.replaceAll(">", "&gt;");
		sValid = sValid.replaceAll("\"", "&qout;");
		sValid = sValid.replaceAll("'", "&#039;");
		sValid = sValid.replaceAll("[\\\"\\\'][\\s]*javascript:(.*)[\\\"\\\']", "\"\"");
		sValid = sValid.replaceAll("script", "");
		sValid = sValid.replaceAll("alert", "");
		sValid = sValid.replaceAll("onmouseover", "");		
		sValid = sValid.replaceAll("onfocus", "");
		sValid = sValid.replaceAll("javascript:", "");
		sValid = sValid.replaceAll("./", "");
		
		Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");		
		
		scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		sInvalid= scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		scriptPattern = Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		sInvalid = scriptPattern.matcher(sInvalid).replaceAll("");
		
		return sValid;
	}

	public static String getSQLInjectionFilter(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}
		sValid = sValid.replaceAll(" (?i)or ", "");
		sValid = sValid.replaceAll(" (?i)and ", "");
		sValid = sValid.replaceAll(" (?i)select ", "");
		sValid = sValid.replaceAll(" (?i)delete ", "");
		sValid = sValid.replaceAll(" (?i)insert ", "");
		sValid = sValid.replaceAll(";", "");
		sValid = sValid.replaceAll(":", "");
		sValid = sValid.replaceAll("--", "");
		sValid = sValid.replaceAll("\\\\", "");
		sValid = sValid.replaceAll("'", "");
		sValid = sValid.replaceAll("\"", "");
		sValid = sValid.replaceAll("(?i)update ", "");
		sValid = sValid.replaceAll("(?i)create ", "");
		sValid = sValid.replaceAll("(?i)drop ", "");
		sValid = sValid.replaceAll("(?i)union ", "");
		sValid = sValid.replaceAll(" (?i)from ", "");
		sValid = sValid.replaceAll(" (?i)where ", "");
		sValid = sValid.replaceAll(" (?i)limit ", "");
		sValid = sValid.replaceAll("ltrim\\(", "");
		sValid = sValid.replaceAll("rtrim\\(", "");		
		sValid = sValid.replaceAll("\\(", "");
		sValid = sValid.replaceAll("\\)", "");
		sValid = sValid.replaceAll("\\|\\|", "");
		sValid = sValid.replaceAll("\\+", "");
		sValid = sValid.replaceAll("\\-", "");

		return sValid;
	}

	public static String getSQLInjectionFilter2(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}
		sValid = sValid.replaceAll(" (?i)or ", "");
		sValid = sValid.replaceAll(" (?i)and ", "");
		sValid = sValid.replaceAll(" (?i)select ", "");
		sValid = sValid.replaceAll(" (?i)delete ", "");
		sValid = sValid.replaceAll(" (?i)insert ", "");
		sValid = sValid.replaceAll(";", "");
		sValid = sValid.replaceAll(":", "");
		sValid = sValid.replaceAll("--", "");
		sValid = sValid.replaceAll("\\\\", "");

		return sValid;
	}

	public static String getHMFilter(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}
		sValid = sValid.replaceAll("\\n", "");
		sValid = sValid.replaceAll("\\r", "");
		return sValid;
	}

	public static String getPMFilter(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}
		sValid = sValid.replaceAll("\\.\\./", "");

		if ((sValid.endsWith(".jsp")) || (sValid.endsWith(".asp"))
				|| (sValid.endsWith(".php")) || (sValid.endsWith(".js"))) {
			sValid = sValid + ".txt";
		}
		return sValid;
	}

	public static String getDFIFilter(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.length() < 1)) {
			return "";
		}
		sValid = sValid.replaceAll("\\.\\./|\\./|\\|:|\\*|\"|<|>", "");

		return sValid;
	}

	public static String getCIFilter(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}
		sValid = sValid.replaceAll("&", "");
		sValid = sValid.replaceAll("\\|", "");
		sValid = sValid.replaceAll(";", "");
		sValid = sValid.replaceAll("\\.\\.", "");

		return sValid;
	}

	public static String getLFFilter(String sInvalid) {
		String sValid = sInvalid;

		if ((sValid == null) || (sValid.equals(""))) {
			return "";
		}
		sValid = sValid.replaceAll("\\r", "");
		sValid = sValid.replaceAll("\\n", "");
		sValid = sValid.replaceAll("DEBUG", "");
		sValid = sValid.replaceAll("WARN", "");
		sValid = sValid.replaceAll("INFO", "");
		sValid = sValid.replaceAll("FATAL", "");
		sValid = sValid.replaceAll("ERROR", "");

		return sValid;
	}
}