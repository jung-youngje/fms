// FAQ ����onmouseover, onmouseout
function hover(obj_id, src_path) {
	document.getElementById(obj_id).src = getContextPath() + src_path;
}

// FAQ ���� click
function showFaqCont(id_no) {
	var img_path = getContextPath()  + "/img/faq/";
	var img_id_tmp = "img_faq_0";
	var img_id = "";
	var arr_id_tmp = "arr_faq_0";
	var arr_id = "";
	
	var div_id_tmp = "div_faq_0";
	var div_id = "";
	
	for(var i=1; i<7; i++) {
		div_id = div_id_tmp + i;
		img_id = img_id_tmp + i;
		arr_id = arr_id_tmp + i;
		
		if(i == id_no) {
			if("" == document.getElementById(div_id).style.display) {
				document.getElementById(img_id).src = img_path + "faq0" + i + ".gif";
				document.getElementById(arr_id).src = img_path + "faq_arr_off.gif";
				document.getElementById(div_id).style.display = "none";
			} else {
				document.getElementById(img_id).src = img_path + "faq0" + i + "_on.gif";
				document.getElementById(arr_id).src = img_path + "faq_arr_on.gif";
				document.getElementById(div_id).style.display = "";
			}
			
		} else {
			document.getElementById(img_id).src = img_path + "faq0" + i + ".gif";
			document.getElementById(arr_id).src = img_path + "faq_arr_off.gif";
			document.getElementById(div_id).style.display = "none";
		}
	}
}