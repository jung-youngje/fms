// ������ �̵�
function moveToPage(page) {
	if("G" == page) {// �������̵�
		location.href = getContextPath() + "/guide.do";
	} else if("D" == page) {// �ٿ�ε�		/
		location.href = getContextPath() + "/downloadview.do?service_kubun=01";		
	} else if("E" == page) {// �����ڵ���ȸ
		location.href = getContextPath() +  "/errorcodeView.do";
	} else if("N" == page) {// ����&��������
		location.href = getContextPath() + "/newslist.do";
	} else if("F" == page) {// FAQ
		location.href = getContextPath() + "/faq.do";
	} 
}

function change_img(obj, src) {
	obj.src = getContextPath() + src;
}

//���ڸ� �Է�
function inputNumber(e) {// e : event
	
	var keyCode = e.keyCode
		
	 if(keyCode == 0){
		 keyCode = e.which;
	 }
	if(keyCode < 48 || keyCode > 57) {
		e.returnValue = false;
		return false;
	}
	return true;
}


function getContextPath(){
    var offset=location.href.indexOf(location.host)+location.host.length;
    var ctxPath=location.href.substring(offset,location.href.indexOf('/',offset+1));
    return ctxPath;
}
